import logging
import os
import python_socks # type: ignore
from dotenv import load_dotenv
import google.generativeai as genai
import redis

# --- Загрузка переменных окружения (для локального запуска) ---
# Путь к .env файлу относительно текущего файла (config.py)
# В контейнере __file__ это /app/config.py
# os.path.dirname(__file__) это /app
dotenv_path = os.path.join(os.path.dirname(__file__), '.env')

_early_session_name_for_log = os.getenv('TELEGRAM_SESSION_NAME', 'agent_early_init')

if os.path.exists(dotenv_path):
    load_dotenv(dotenv_path)
    # Обновляем имя для ранних логов, если оно есть в .env
    _early_session_name_for_log = os.getenv('TELEGRAM_SESSION_NAME', _early_session_name_for_log)
    print(f"[Agent {_early_session_name_for_log}] Загружен локальный .env файл: {dotenv_path}")
else:
    print(f"[Agent {_early_session_name_for_log}] Файл {dotenv_path} не найден. Используются переменные окружения системы/Docker.")


# --- Объявление переменных конфигурации с типами и значениями по умолчанию ---
TELEGRAM_API_ID: int | None = None
TELEGRAM_API_HASH: str | None = None
TELEGRAM_SESSION_NAME: str | None = None 
GEMINI_API_KEY: str | None = None
TELEGRAM_SESSION_STRING: str | None = None
GEMINI_MODEL_NAME: str = 'gemini-1.5-flash-latest' # Значение по умолчанию
BOT_NAME_FROM_ENV: str | None = None # Имя бота из переменной окружения (приоритет)
AGENT_LOG_LEVEL_STR: str = 'INFO' # Значение по умолчанию
REDIS_HOST: str = 'redis' # Значение по умолчанию для Docker
_redis_port_str_default: str = '6379'
REDIS_PORT: int = 6379 # Будет переопределено из env, если есть
_user_state_ttl_default: str = str(7 * 24 * 60 * 60) # 7 дней в секундах
USER_STATE_TTL_SECONDS: int = int(_user_state_ttl_default) # Будет переопределено

# Telethon Proxy Settings Dictionary
TELETHON_PROXY_SETTINGS: dict | None = None


# --- Чтение и валидация конфигурации ---
try:
    _api_id_env_str = os.getenv('TELEGRAM_API_ID')
    if not _api_id_env_str: raise ValueError("Переменная окружения TELEGRAM_API_ID не установлена или пуста.")
    TELEGRAM_API_ID = int(_api_id_env_str)

    TELEGRAM_API_HASH = os.getenv('TELEGRAM_API_HASH')
    TELEGRAM_SESSION_NAME = os.getenv('TELEGRAM_SESSION_NAME') # Может быть None, проверяется ниже
    GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')
    TELEGRAM_SESSION_STRING = os.getenv('TELEGRAM_SESSION_STRING') # Проверяется на None перед использованием в agent_main

    GEMINI_MODEL_NAME = os.getenv('GEMINI_MODEL_NAME', GEMINI_MODEL_NAME) # Используем default если не задано
    BOT_NAME_FROM_ENV = os.getenv('BOT_NAME_OVERRIDE') # Имя из .env
    AGENT_LOG_LEVEL_STR = os.getenv('LOG_LEVEL', AGENT_LOG_LEVEL_STR).upper()
    REDIS_HOST = os.getenv('REDIS_HOST', REDIS_HOST)

    _redis_port_env_str = os.getenv('REDIS_PORT', _redis_port_str_default)
    if not _redis_port_env_str or not _redis_port_env_str.isdigit():
        raise ValueError(f"REDIS_PORT ('{_redis_port_env_str}') должен быть числом.")
    REDIS_PORT = int(_redis_port_env_str)

    _user_state_ttl_env_str = os.getenv('USER_STATE_TTL_SECONDS', _user_state_ttl_default)
    if not _user_state_ttl_env_str or not _user_state_ttl_env_str.isdigit():
        raise ValueError(f"USER_STATE_TTL_SECONDS ('{_user_state_ttl_env_str}') должен быть числом.")
    USER_STATE_TTL_SECONDS = int(_user_state_ttl_env_str)

    # Telethon Proxy Configuration
    _proxy_type_env_str = os.getenv('TELETHON_PROXY_TYPE')
    _proxy_host_env = os.getenv('TELETHON_PROXY_HOST')
    _proxy_port_env_str = os.getenv('TELETHON_PROXY_PORT')
    
    if _proxy_host_env and _proxy_port_env_str and _proxy_type_env_str:
        if not _proxy_port_env_str.isdigit():
            raise ValueError(f"TELETHON_PROXY_PORT ('{_proxy_port_env_str}') должен быть числом.")
        _proxy_port_val = int(_proxy_port_env_str)
        _proxy_username_env = os.getenv('TELETHON_PROXY_USERNAME')
        _proxy_password_env = os.getenv('TELETHON_PROXY_PASSWORD')
        
        proxy_type_map = {
            'socks5': python_socks.ProxyType.SOCKS5,
            'socks4': python_socks.ProxyType.SOCKS4,
            'http': python_socks.ProxyType.HTTP,
        }
        selected_proxy_type_val = proxy_type_map.get(_proxy_type_env_str.lower())

        if selected_proxy_type_val:
            rdns_val = True if selected_proxy_type_val in [python_socks.ProxyType.SOCKS5, python_socks.ProxyType.SOCKS4] else False
            TELETHON_PROXY_SETTINGS = {
                "proxy_type": selected_proxy_type_val,
                "addr": _proxy_host_env,
                "port": _proxy_port_val,
                "rdns": rdns_val,
                "username": _proxy_username_env or None, # None если пустая строка
                "password": _proxy_password_env or None  # None если пустая строка
            }
        else:
            # Логируем предупреждение, но не падаем, агент запустится без прокси
            print(f"[Agent Config {_early_session_name_for_log}] Указан неизвестный тип прокси '{_proxy_type_env_str}'. Прокси не будет использован.")
    
except (TypeError, ValueError) as e_config:
    # Используем _early_session_name_for_log, так как TELEGRAM_SESSION_NAME может быть еще не установлен
    current_session_name_for_error_log = TELEGRAM_SESSION_NAME or _early_session_name_for_log
    # Собираем значения переменных, которые могли вызвать ошибку
    problematic_values_for_debug = {
        "TELEGRAM_API_ID": os.getenv('TELEGRAM_API_ID'),
        "REDIS_PORT": os.getenv('REDIS_PORT'),
        "USER_STATE_TTL_SECONDS": os.getenv('USER_STATE_TTL_SECONDS'),
        "TELETHON_PROXY_PORT": os.getenv('TELETHON_PROXY_PORT') # Используем имя переменной из env
    }
    print(f"Критическая ошибка [Agent Config {current_session_name_for_error_log}]: Неверный тип или значение переменной окружения: {e_config}. "
          f"Значения потенциально проблемных переменных: {problematic_values_for_debug}")
    exit(1) # Критическая ошибка конфигурации - выходим

# --- Проверка на обязательные переменные после попытки их прочитать ---
critical_env_vars_check = {
    "TELEGRAM_API_ID": TELEGRAM_API_ID,
    "TELEGRAM_API_HASH": TELEGRAM_API_HASH,
    "TELEGRAM_SESSION_NAME": TELEGRAM_SESSION_NAME, 
    "GEMINI_API_KEY": GEMINI_API_KEY,
    # TELEGRAM_SESSION_STRING проверяется отдельно в agent_main.py перед запуском клиента Telethon
}
missing_vars_list_check = [name for name, value in critical_env_vars_check.items() if not value] # Проверяем на falsy (None, пустая строка)

if missing_vars_list_check:
    current_session_name_for_error_log = TELEGRAM_SESSION_NAME or _early_session_name_for_log
    print(f"Критическая ошибка [Agent Config {current_session_name_for_error_log}]: Следующие обязательные переменные окружения не установлены или пусты: {', '.join(missing_vars_list_check)}")
    exit(1)

# --- Настройка логирования Агента ---
# TELEGRAM_SESSION_NAME здесь гарантированно не None и не пустой, так как прошел проверку выше.
agent_numeric_log_level_val = getattr(logging, AGENT_LOG_LEVEL_STR, logging.INFO)
logger = logging.getLogger(f"Agent_{TELEGRAM_SESSION_NAME}") # Используем TELEGRAM_SESSION_NAME в имени логгера
logger.setLevel(agent_numeric_log_level_val)

if not logger.hasHandlers(): # Предотвращаем дублирование хендлеров при повторном импорте (маловероятно, но безопасно)
    log_formatter_val = logging.Formatter(f'[%(levelname)5s/%(asctime)s] %(name)s: %(message)s')
    stream_handler_val = logging.StreamHandler()
    stream_handler_val.setFormatter(log_formatter_val)
    logger.addHandler(stream_handler_val)
    logger.propagate = False # Не передавать сообщения вышестоящим логгерам (root)

logger.info(f"Уровень логирования для агента '{TELEGRAM_SESSION_NAME}': {AGENT_LOG_LEVEL_STR}")
if TELETHON_PROXY_SETTINGS:
    proxy_info_log = (
        f"{TELETHON_PROXY_SETTINGS['proxy_type'].name}://"
        f"{TELETHON_PROXY_SETTINGS['addr']}:{TELETHON_PROXY_SETTINGS['port']} "
        f"(RDNS: {TELETHON_PROXY_SETTINGS['rdns']})"
    )
    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}' будет использовать прокси: {proxy_info_log}")


# --- Инициализация клиента Redis ---
redis_client: redis.StrictRedis | None = None
try:
    # decode_responses=False, так как state_manager ожидает байты для json.loads
    redis_client = redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=0, decode_responses=False) 
    redis_client.ping()
    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Успешное подключение к Redis: {REDIS_HOST}:{REDIS_PORT}")
except redis.exceptions.ConnectionError as e_redis_conn:
    logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': КРИТИЧЕСКАЯ ОШИБКА - Redis недоступен ({REDIS_HOST}:{REDIS_PORT}): {e_redis_conn}", exc_info=True)
    redis_client = None # Агент может попытаться запуститься, но state_manager будет работать с default состоянием


# --- Инициализация Gemini ---
gemini_model: genai.GenerativeModel | None = None
try:
    if not GEMINI_API_KEY: # Уже проверено выше, но для ясности
        raise ValueError("GEMINI_API_KEY не установлен.")
    genai.configure(api_key=GEMINI_API_KEY)
    gemini_model = genai.GenerativeModel(GEMINI_MODEL_NAME)
    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Модель Gemini '{GEMINI_MODEL_NAME}' успешно инициализирована.")
except Exception as e_gemini_init:
    logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': КРИТИЧЕСКАЯ ОШИБКА - Gemini не инициализирован: {e_gemini_init}", exc_info=True)
    gemini_model = None # Агент может попытаться запуститься, но message_handler вернет ошибку

# Глобальная переменная для имени бота, которое может быть установлено динамически.
# Инициализируется из BOT_NAME_FROM_ENV (которое может быть None).
# Если BOT_NAME_FROM_ENV None, то agent_main.py попытается установить его из профиля Telegram.
CURRENT_BOT_NAME: str | None = BOT_NAME_FROM_ENV