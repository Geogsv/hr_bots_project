# agent_bot/message_handler.py
import google.generativeai as genai
from google.generativeai.types import HarmCategory, HarmBlockThreshold
from config import logger, gemini_model, TELEGRAM_SESSION_NAME
from constants import SCENARIO, IMPROVED_SYSTEM_PROMPT_TEMPLATE
from state_manager import (
    get_user_state, save_user_state, add_to_chat_history,
    update_anketa_answer, advance_user_stage
)

async def generate_gemini_response(user_id: int, current_stage_id_for_prompt: str, current_task_instruction: str, actual_bot_name_for_gemini: str, user_message_text_for_history: str | None = None) -> str:
    if not gemini_model:
        logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Модель Gemini не инициализирована. Не могу сгенерировать ответ для пользователя {user_id}.")
        return "Извините, в данный момент я не могу обработать ваш запрос. Пожалуйста, попробуйте связаться позже."

    state = get_user_state(user_id) # Получаем актуальное состояние
    if user_message_text_for_history:
        add_to_chat_history(user_id, "user", user_message_text_for_history)
        state = get_user_state(user_id) # Перезагружаем состояние с обновленной историей

    system_prompt_text = IMPROVED_SYSTEM_PROMPT_TEMPLATE.format(
        bot_name=actual_bot_name_for_gemini,
        current_task_instruction=current_task_instruction,
        current_stage_id=current_stage_id_for_prompt
    )

    contents_for_gemini_api = [{"role": "user", "parts": [{"text": system_prompt_text}]}]
    last_role_in_history = "user"
    chat_history_for_api = state.get("chat_history", []) # Используем историю из актуального state
    for history_entry in chat_history_for_api:
        if history_entry["role"] == last_role_in_history:
            logger.debug(f"Агент '{TELEGRAM_SESSION_NAME}': Пропуск послед. сообщения от '{last_role_in_history}' для {user_id}.")
            continue
        contents_for_gemini_api.append(history_entry)
        last_role_in_history = history_entry["role"]

    logger.debug(f"Агент '{TELEGRAM_SESSION_NAME}': Запрос Gemini для {user_id}. Этап: {current_stage_id_for_prompt}. Инстр: '{current_task_instruction[:100]}...'. Сообщений в `contents`: {len(contents_for_gemini_api)}.")

    safety_settings_config = {
        HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_NONE,
        HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_NONE,
        HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_NONE,
        HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
    }

    try:
        gemini_api_response = await gemini_model.generate_content_async(
            contents=contents_for_gemini_api,
            generation_config=genai.types.GenerationConfig(temperature=0.75, top_p=0.95), # Температуру можно чуть поднять для "человечности"
            safety_settings=safety_settings_config
        )
        bot_response_text = ""
        if gemini_api_response.candidates and gemini_api_response.candidates[0].content.parts:
            bot_response_text = "".join(part.text for part in gemini_api_response.candidates[0].content.parts)
        
        if not bot_response_text:
            # ... (обработка блокировки, как раньше)
            block_reason = "Причина неизвестна"
            if gemini_api_response.prompt_feedback and gemini_api_response.prompt_feedback.block_reason:
                block_reason = gemini_api_response.prompt_feedback.block_reason.name
            logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Gemini вернул пустой ответ для {user_id}. Причина: {block_reason}")
            return "Простите, не совсем поняла вас. Можете повторить?" # Более человечный ответ при ошибке
            
        add_to_chat_history(user_id, "model", bot_response_text)
        return bot_response_text.strip()
    except Exception as e_gemini_call:
        logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка Gemini API для {user_id}: {type(e_gemini_call).__name__} - {e_gemini_call}", exc_info=True)
        return f"Ой, кажется, у меня небольшие технические неполадки. Попробуйте написать чуть позже, пожалуйста. ({actual_bot_name_for_gemini} 😊)"


async def handle_user_message(user_id: int, message_text: str, actual_bot_name: str) -> str:
    state = get_user_state(user_id)
    current_stage_id = state.get("current_stage_id", SCENARIO["initial_stage_id"])
    anketa_answers = state.get("anketa_answers", {})

    # Проверка на "Ты бот?"
    if message_text and ("ты бот" in message_text.lower() or "ты человек" in message_text.lower() or "ии ли ты" in message_text.lower()):
        # Gemini сам должен ответить на это согласно системному промпту.
        # Мы просто передаем это как обычное сообщение.
        # Но можно и захардкодить, если ответы Gemini не устраивают.
        # return random.choice(["Хах, забавный вопрос! Конечно, человек, просто работы много 😊", ...])
        pass # Позволим Gemini обработать это


    # Если анкета завершена и кандидат просто пишет, чтобы узнать статус
    if current_stage_id == SCENARIO["anketa_completed_stage_id"] and \
       state.get("chat_history"): # Убедимся, что это не первый вход в это состояние
        # Проверяем, не слишком ли часто пишет кандидат
        # (Это можно усложнить, проверяя время последнего сообщения)
        logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Пользователь {user_id} (анкета завершена) пишет снова. Переход в WARM_UP.")
        current_stage_id = "WARM_UP_CANDIDATE"
        # advance_user_stage(user_id, "WARM_UP_CANDIDATE") # Переход будет ниже, если Gemini не изменит


    if current_stage_id not in SCENARIO["stages"]:
        logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Неизвестный этап {current_stage_id} для {user_id}. Сброс.")
        current_stage_id = SCENARIO["initial_stage_id"]
        state["current_stage_id"] = current_stage_id
        state["chat_history"] = []
        state["anketa_answers"] = {}
        save_user_state(user_id, state) # Сохраняем сброшенное состояние

    current_stage_data = SCENARIO["stages"][current_stage_id]
    
    # Формируем инструкцию для Gemini, подставляя имя кандидата, если оно известно и если это этап WARM_UP
    gemini_instruction_for_stage = current_stage_data["instruction_for_gemini"]
    if current_stage_id == "WARM_UP_CANDIDATE":
        candidate_name_from_anketa = anketa_answers.get("name", "кандидат") # "кандидат" как fallback
        gemini_instruction_for_stage = gemini_instruction_for_stage.format(
            bot_name=actual_bot_name, 
            candidate_name=candidate_name_from_anketa
        )
    else:
        gemini_instruction_for_stage = gemini_instruction_for_stage.format(bot_name=actual_bot_name)


    user_message_to_add = message_text
    should_add_user_msg_to_history = True
    if not message_text and current_stage_id != SCENARIO["initial_stage_id"]:
        user_message_to_add = "[Кандидат отправил нетекстовое/пустое сообщение или стикер]"
    
    if current_stage_id == SCENARIO["initial_stage_id"] and not state.get("chat_history"):
        should_add_user_msg_to_history = False
        user_message_to_add = None


    bot_response = await generate_gemini_response(
        user_id,
        current_stage_id_for_prompt=current_stage_id,
        current_task_instruction=gemini_instruction_for_stage,
        actual_bot_name_for_gemini=actual_bot_name,
        user_message_text_for_history=user_message_to_add if should_add_user_msg_to_history else None
    )

    # --- Логика сохранения ответов и перехода на следующий этап ---
    next_stage_to_set = current_stage_data.get("next_stage_default")

    # Сохраняем ответы на вопросы анкеты
    if message_text: # Только если есть текстовый ответ от пользователя
        if current_stage_id == "GREETING_AND_NAME":
            update_anketa_answer(user_id, "name", message_text)
        elif current_stage_id == "ASK_AGE":
            update_anketa_answer(user_id, "age", message_text)
        elif current_stage_id == "ASK_CITY":
            update_anketa_answer(user_id, "city", message_text)
        elif current_stage_id == "ASK_EXPERIENCE":
            update_anketa_answer(user_id, "experience", message_text)
        elif current_stage_id == "ASK_LICENSE_OR_AVAILABILITY":
            # Ключ может быть разным, для простоты 'license_or_availability'
            update_anketa_answer(user_id, "license_or_availability", message_text)
        elif current_stage_id == "ASK_SALARY_EXPECTATIONS":
            update_anketa_answer(user_id, "salary_expectation", message_text)
        # На этапе SALARY_LURE и ANKETA_COMPLETED мы уже не сохраняем ответы, а работаем с реакцией
        # На этапе WARM_UP тоже не сохраняем, это просто общение

    # Переход на следующий этап, если он определен
    if next_stage_to_set and \
       current_stage_id != SCENARIO["anketa_completed_stage_id"] and \
       current_stage_id != "WARM_UP_CANDIDATE": # Не переходим автоматически из этих состояний
        advance_user_stage(user_id, next_stage_to_set)
    elif current_stage_id == "WARM_UP_CANDIDATE":
        # Остаемся в WARM_UP, если кандидат продолжает писать
        # advance_user_stage(user_id, current_stage_id) # Обновит TTL и last_activity
        pass # state_manager.save_user_state вызовется в get_user_state или add_to_chat_history
    elif current_stage_id == SCENARIO["anketa_completed_stage_id"]:
        # После завершения анкеты мы ждем, если кандидат напишет снова, тогда перейдем в WARM_UP (логика выше)
        pass
        
    return bot_response