# agent_bot/state_manager.py
import json
from datetime import datetime, timezone
import redis
from config import (
    logger, redis_client, TELEGRAM_SESSION_NAME, USER_STATE_TTL_SECONDS
)
from constants import SCENARIO # SCENARIO теперь содержит initial_stage_id

def get_redis_key_for_user_state(user_id: int) -> str:
    if not TELEGRAM_SESSION_NAME:
        logger.error("Критическая ошибка: TELEGRAM_SESSION_NAME не был инициализирован при попытке сформировать ключ Redis.")
        raise ValueError("TELEGRAM_SESSION_NAME (имя сессии агента) не определено в конфигурации.")
    return f"agent:{TELEGRAM_SESSION_NAME}:user_state:{user_id}"

def save_user_state(user_id: int, state: dict):
    if not redis_client:
        logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Redis клиент не инициализирован. Не могу сохранить состояние для пользователя {user_id}.")
        return
    try:
        key = get_redis_key_for_user_state(user_id)
        state["last_activity_iso"] = datetime.now(timezone.utc).isoformat()
        redis_client.setex(key, USER_STATE_TTL_SECONDS, json.dumps(state))
        logger.debug(f"Агент '{TELEGRAM_SESSION_NAME}': Состояние пользователя {user_id} сохранено. Этап: {state.get('current_stage_id')}. Ключевые ответы: {state.get('anketa_answers', {}).get('name', 'N/A')}")
    except (redis.exceptions.RedisError, TypeError, json.JSONDecodeError) as e:
        logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка при сохранении состояния пользователя {user_id} в Redis: {e}", exc_info=True)

def get_user_state(user_id: int) -> dict:
    default_user_state = {
        "current_stage_id": SCENARIO["initial_stage_id"],
        "anketa_answers": {}, # Для хранения ответов на ключевые вопросы (имя, ожидания по ЗП и т.д.)
        "chat_history": [],
        "last_activity_iso": datetime.now(timezone.utc).isoformat()
    }
    if not redis_client:
        logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Redis клиент не инициализирован. Возвращаю временное состояние по умолчанию для пользователя {user_id}.")
        return default_user_state.copy()
    
    key = get_redis_key_for_user_state(user_id)
    try:
        state_json_bytes = redis_client.get(key)
        if state_json_bytes:
            state_data = json.loads(state_json_bytes.decode('utf-8'))
            
            # Проверка и инициализация current_stage_id, если отсутствует или некорректен
            if "current_stage_id" not in state_data or state_data["current_stage_id"] not in SCENARIO["stages"]:
                logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': У пользователя {user_id} некорректный или отсутствующий этап '{state_data.get('current_stage_id')}'. Сброс на начальный.")
                state_data["current_stage_id"] = SCENARIO["initial_stage_id"]
                state_data["chat_history"] = state_data.get("chat_history", []) # Сохраняем историю, если есть
                state_data["anketa_answers"] = state_data.get("anketa_answers", {}) # Сохраняем ответы, если есть
            
            # Инициализация anketa_answers, если отсутствует
            if "anketa_answers" not in state_data:
                state_data["anketa_answers"] = {}

            redis_client.expire(key, USER_STATE_TTL_SECONDS)
            logger.debug(f"Агент '{TELEGRAM_SESSION_NAME}': Состояние пользователя {user_id} загружено. Этап: {state_data.get('current_stage_id')}. TTL продлен.")
            state_data["last_activity_iso"] = datetime.now(timezone.utc).isoformat()
            return state_data
    except (redis.exceptions.RedisError, json.JSONDecodeError, TypeError) as e:
        logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка при загрузке состояния пользователя {user_id} из Redis: {e}", exc_info=True)
    
    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Для пользователя {user_id} не найдено состояние. Инициализация нового.")
    new_state = default_user_state.copy()
    save_user_state(user_id, new_state)
    return new_state

def add_to_chat_history(user_id: int, role: str, text: str):
    state = get_user_state(user_id)
    if text and text.strip():
        state.setdefault("chat_history", []) # Убедимся, что ключ существует
        state["chat_history"].append({"role": role, "parts": [{"text": text.strip()}]})
        if len(state["chat_history"]) > 15: # Немного увеличим лимит
            state["chat_history"] = state["chat_history"][-15:]
        save_user_state(user_id, state)

def update_anketa_answer(user_id: int, answer_key: str, answer_value: str):
    """Сохраняет конкретный ответ из анкеты (имя, возраст, город и т.д.)."""
    state = get_user_state(user_id)
    state.setdefault("anketa_answers", {}) # Убедимся, что ключ существует
    state["anketa_answers"][answer_key] = answer_value.strip()
    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Пользователь {user_id} - анкета обновлена: {answer_key} = '{answer_value[:30]}...'")
    save_user_state(user_id, state)

def advance_user_stage(user_id: int, next_stage_id: str):
    state = get_user_state(user_id)
    current_stage_log = state.get('current_stage_id', 'N/A')
    
    if next_stage_id not in SCENARIO["stages"]:
        logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Попытка перейти на несуществующий этап '{next_stage_id}' для пользователя {user_id}. Текущий этап: {current_stage_log}. Этап не изменен.")
        # Можно добавить логику сброса на initial_stage_id или другую обработку ошибки
        return

    if state.get("current_stage_id") == next_stage_id:
        logger.debug(f"Агент '{TELEGRAM_SESSION_NAME}': Пользователь {user_id} уже на этапе '{next_stage_id}'. Переход не требуется.")
        # Обновляем last_activity_iso и сохраняем, если нужно обновить TTL
        save_user_state(user_id, state)
        return

    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Пользователь {user_id} переходит с этапа '{current_stage_log}' на этап '{next_stage_id}'")
    state["current_stage_id"] = next_stage_id
    save_user_state(user_id, state)