# admin_bot/handlers/callbacks.py
import asyncio
import docker # type: ignore
from telegram import Update, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from config import logger, DOCKER_CLIENT
from auth import restricted
from redis_utils import load_agents_config, save_agents_config
from docker_utils import (
    start_agent_container, stop_agent_container,
    get_container_name, DOCKER_CLIENT as DOCKER_CLIENT_FROM_UTILS
)
from handlers.commands import start_panel_command, show_agents_list_menu, show_agent_management_menu_content
# from ui.keyboards import get_confirm_delete_keyboard # Заменено на динамический импорт
from constants import (
    ACTION_BACK_TO_LIST, ACTION_MAIN_MENU, ACTION_ADD_AGENT_CONV_START,
    ACTION_PREFIX_VIEW_AGENT, ACTION_PREFIX_TOGGLE_AGENT,
    ACTION_PREFIX_AGENT_LOGS, ACTION_PREFIX_CONFIRM_DELETE_AGENT,
    ACTION_PREFIX_DO_DELETE_AGENT
)

@restricted
async def button_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not query or not query.data or not query.from_user:
        logger.warning("button_callback_handler вызван с неполным query объектом.")
        if query: await query.answer()
        return
    await query.answer()
    data: str = query.data
    user_id = query.from_user.id
    user_name = query.from_user.first_name
    logger.info(f"Пользователь {user_id} ({user_name}) нажал кнопку с callback_data: '{data}'")

    if data == ACTION_BACK_TO_LIST:
        await show_agents_list_menu(update, context)
    elif data == ACTION_MAIN_MENU:
        await start_panel_command(update, context)
    elif data == ACTION_ADD_AGENT_CONV_START:
        if not DOCKER_CLIENT:
            if query.message:
                await query.message.reply_text("Docker клиент недоступен. Добавление агента невозможно.")
            else:
                logger.warning("Кнопка ACTION_ADD_AGENT_CONV_START нажата без query.message")
            return
        if query.message:
            await query.message.reply_text(
                "Для добавления нового HR-Агента, пожалуйста, используйте команду /add_agent\n\n"
                "Это запустит пошаговый диалог для ввода всех необходимых данных.\n"
                "Вы можете отменить процесс добавления в любой момент командой /cancel."
            )
    elif data.startswith(ACTION_PREFIX_VIEW_AGENT):
        session_name_to_view = data[len(ACTION_PREFIX_VIEW_AGENT):]
        await show_agent_management_menu_content(update, context, session_name_to_view)
    elif data.startswith(ACTION_PREFIX_TOGGLE_AGENT):
        session_name_to_toggle = data[len(ACTION_PREFIX_TOGGLE_AGENT):]
        agents_configs = load_agents_config()
        if session_name_to_toggle in agents_configs:
            agent_to_toggle_config = agents_configs[session_name_to_toggle]
            should_be_started = not agent_to_toggle_config.get("is_active", False)
            action_description_log = "Запуск" if should_be_started else "Остановка"
            if query.message:
                await query.message.edit_text(
                    f"{action_description_log} агента `{session_name_to_toggle}`...", 
                    parse_mode=ParseMode.MARKDOWN
                )
            action_function = start_agent_container if should_be_started else stop_agent_container
            args_for_action = (session_name_to_toggle, agent_to_toggle_config, context) if should_be_started else (session_name_to_toggle, context)
            action_successful = await action_function(*args_for_action) # type: ignore
            await asyncio.sleep(1.0 if should_be_started else 0.5) 
            await show_agent_management_menu_content(update, context, session_name_to_toggle)
        else:
            await query.answer("Агент для переключения не найден в конфигурации.", show_alert=True)
            await show_agents_list_menu(update, context)
    elif data.startswith(ACTION_PREFIX_CONFIRM_DELETE_AGENT):
        from ui.keyboards import get_confirm_delete_keyboard # Динамический импорт
        session_name_to_confirm_delete = data[len(ACTION_PREFIX_CONFIRM_DELETE_AGENT):]
        confirm_delete_keyboard = get_confirm_delete_keyboard(session_name_to_confirm_delete)
        if query.message:
            await query.message.edit_text(
                f"Вы уверены, что хотите удалить агента `{session_name_to_confirm_delete}`?\n"
                f"Это действие приведет к удалению его конфигурации, Docker-контейнера и связанного с ним Docker-volume (если они существуют). "
                f"Это действие необратимо.",
                reply_markup=confirm_delete_keyboard,
                parse_mode=ParseMode.MARKDOWN
            )
    elif data.startswith(ACTION_PREFIX_DO_DELETE_AGENT):
        session_name_to_delete = data[len(ACTION_PREFIX_DO_DELETE_AGENT):]
        current_agents_config = load_agents_config()
        if session_name_to_delete in current_agents_config:
            if query.message:
                await query.message.edit_text(
                    f"Удаление агента `{session_name_to_delete}` и связанных Docker-ресурсов...", 
                    parse_mode=ParseMode.MARKDOWN
                )
            docker_cleanup_successful = await stop_agent_container(session_name_to_delete, context, remove_container_and_volume=True) # type: ignore
            if docker_cleanup_successful:
                del current_agents_config[session_name_to_delete]
                save_agents_config(current_agents_config)
                logger.info(f"Агент {session_name_to_delete} успешно удален из конфигурации Redis.")
            else:
                logger.warning(f"Конфигурация агента {session_name_to_delete} не удалена из Redis из-за проблем с удалением Docker ресурсов.")
                await query.answer("Произошла ошибка при удалении Docker ресурсов. Конфигурация агента не была удалена из Redis.", show_alert=True)
            await asyncio.sleep(0.5) 
            await show_agents_list_menu(update, context, edit_message=bool(query.message)) 
        else:
            await query.answer("Агент уже удален из конфигурации или не найден.", show_alert=True)
            await show_agents_list_menu(update, context, edit_message=bool(query.message))
    elif data.startswith(ACTION_PREFIX_AGENT_LOGS):
        session_name_for_logs = data[len(ACTION_PREFIX_AGENT_LOGS):]
        container_name_for_logs = get_container_name(session_name_for_logs)
        logs_response_text = f"Логи для агента `{session_name_for_logs}` (контейнер: `{container_name_for_logs}`):\n"
        if DOCKER_CLIENT_FROM_UTILS: 
            try:
                container_obj = DOCKER_CLIENT_FROM_UTILS.containers.get(container_name_for_logs)
                raw_logs = container_obj.logs(tail=20).decode('utf-8', 'replace') 
                logs_response_text += f"```text\n{raw_logs or '(Логи пусты или еще не появились)'}\n```"
            except docker.errors.NotFound:
                logs_response_text += "_Контейнер для этого агента не найден в Docker._"
            except Exception as e_docker_logs:
                logs_response_text += f"_Произошла ошибка при получении логов из Docker: {e_docker_logs}_"
        else:
            logs_response_text += "_Docker клиент недоступен, невозможно получить логи._"
        if query.message:
            await query.message.reply_text(logs_response_text, parse_mode=ParseMode.MARKDOWN)
            await query.answer("Логи отправлены.") 
        else: 
            logger.warning(f"Попытка отправить логи для {session_name_for_logs} без query.message")