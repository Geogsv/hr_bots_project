# admin_bot/docker_utils.py
import asyncio
import docker # type: ignore
from typing import Dict, Any
from telegram.ext import ContextTypes
from config import (
    logger, DOCKER_CLIENT, DOCKER_AGENT_IMAGE_NAME,
    GEMINI_API_KEY_FOR_AGENTS, GEMINI_MODEL_NAME_FOR_AGENTS, AGENT_LOG_LEVEL,
    REDIS_HOST, REDIS_PORT, AGENT_DNS_LIST_GLOBAL, DOCKER_AGENT_NETWORK_NAME
)
from redis_utils import update_agent_status_in_config_file
from auth import requires_docker

def get_container_name(session_name: str) -> str:
    safe_session_name = "".join(c if c.isalnum() else '_' for c in session_name)
    return f"hr_agent_container_{safe_session_name.lower()}"

def get_container_status_message(container_name: str) -> str:
    if not DOCKER_CLIENT:
        return "Docker клиент недоступен"
    try:
        container = DOCKER_CLIENT.containers.get(container_name)
        return f"Docker: {container.status}"
    except docker.errors.NotFound:
        return "Docker: Контейнер не найден"
    except Exception as e:
        logger.error(f"Ошибка при получении статуса контейнера {container_name}: {e}")
        return "Docker: Ошибка статуса"

@requires_docker
async def start_agent_container(session_name: str, agent_config: Dict[str, Any], context: ContextTypes.DEFAULT_TYPE) -> bool:
    if not DOCKER_CLIENT:
        logger.error(f"start_agent_container для {session_name}: Docker клиент недоступен (внутренняя проверка).")
        update_agent_status_in_config_file(session_name, "Ошибка: Docker клиент недоступен", is_active=False)
        return False
    container_name = get_container_name(session_name)
    try:
        existing_container = DOCKER_CLIENT.containers.get(container_name)
        if existing_container.status == 'running':
            logger.info(f"Контейнер {container_name} для {session_name} уже запущен.")
            update_agent_status_in_config_file(session_name, get_container_status_message(container_name), is_active=True)
            return True
        else:
            logger.info(f"Контейнер {container_name} существует в статусе '{existing_container.status}'. Удаление перед перезапуском...")
            existing_container.remove(force=True)
    except docker.errors.NotFound:
        logger.info(f"Контейнер {container_name} для {session_name} не найден. Будет создан новый.")
        pass 
    except Exception as e_check:
        logger.error(f"Ошибка при проверке/удалении существующего контейнера {container_name}: {e_check}", exc_info=True)
        update_agent_status_in_config_file(session_name, f"Ошибка Docker (проверка): {str(e_check)[:50]}", is_active=False)
        return False
    env_vars = {
        "TELEGRAM_API_ID": str(agent_config["api_id"]),
        "TELEGRAM_API_HASH": agent_config["api_hash"],
        "TELEGRAM_SESSION_NAME": session_name,
        "GEMINI_API_KEY": GEMINI_API_KEY_FOR_AGENTS,
        "GEMINI_MODEL_NAME": GEMINI_MODEL_NAME_FOR_AGENTS,
        "LOG_LEVEL": AGENT_LOG_LEVEL,
        "REDIS_HOST": REDIS_HOST,
        "REDIS_PORT": str(REDIS_PORT),
    }
    if agent_config.get("session_string"):
        env_vars["TELEGRAM_SESSION_STRING"] = agent_config["session_string"]
    if agent_config.get("bot_name_override"):
        env_vars["BOT_NAME_OVERRIDE"] = agent_config["bot_name_override"]
    proxy_conf = agent_config.get("proxy_config")
    if proxy_conf and isinstance(proxy_conf, dict) and proxy_conf.get("host") and proxy_conf.get("port"):
        env_vars["TELETHON_PROXY_TYPE"] = proxy_conf["type"]
        env_vars["TELETHON_PROXY_HOST"] = proxy_conf["host"]
        env_vars["TELETHON_PROXY_PORT"] = str(proxy_conf["port"])
        if proxy_conf.get("username"): env_vars["TELETHON_PROXY_USERNAME"] = proxy_conf["username"]
        if proxy_conf.get("password"): env_vars["TELETHON_PROXY_PASSWORD"] = proxy_conf["password"]
        if proxy_conf["type"].lower() == "http":
            proxy_url_part = f"{proxy_conf['host']}:{proxy_conf['port']}"
            auth_part = ""
            if proxy_conf.get("username") and proxy_conf.get("password"):
                auth_part = f"{proxy_conf['username']}:{proxy_conf['password']}@"
            elif proxy_conf.get("username"): 
                 auth_part = f"{proxy_conf['username']}@"
            proxy_url = f"http://{auth_part}{proxy_url_part}"
            env_vars["HTTP_PROXY"] = proxy_url
            env_vars["HTTPS_PROXY"] = proxy_url
            logger.info(f"Для агента {session_name} (тип прокси HTTP) установлены HTTP_PROXY/HTTPS_PROXY: {proxy_url}")
    run_parameters: Dict[str, Any] = {
        "image": DOCKER_AGENT_IMAGE_NAME, "detach": True, "name": container_name,
        "environment": env_vars, "restart_policy": {"Name": "unless-stopped"}
    }
    volume_name = f"{container_name}_telethon_session"
    try:
        DOCKER_CLIENT.volumes.get(volume_name)
        logger.debug(f"Volume '{volume_name}' для {session_name} уже существует.")
    except docker.errors.NotFound:
        DOCKER_CLIENT.volumes.create(name=volume_name)
        logger.info(f"Volume '{volume_name}' для {session_name} создан.")
    run_parameters["volumes"] = {volume_name: {'bind': '/app/sessions', 'mode': 'rw'}}
    if AGENT_DNS_LIST_GLOBAL:
        run_parameters["dns"] = AGENT_DNS_LIST_GLOBAL
        logger.info(f"Для контейнера '{container_name}' будут использованы DNS-серверы (из .env): {AGENT_DNS_LIST_GLOBAL}")
    else:
        logger.info(f"Для контейнера '{container_name}' будут использованы DNS-серверы Docker хоста по умолчанию (AGENT_DNS_SERVERS не заданы или невалидны в .env).")
    if DOCKER_AGENT_NETWORK_NAME:
        try:
            DOCKER_CLIENT.networks.get(DOCKER_AGENT_NETWORK_NAME)
            run_parameters["network"] = DOCKER_AGENT_NETWORK_NAME
            logger.info(f"Контейнер '{container_name}' будет подключен к сети '{DOCKER_AGENT_NETWORK_NAME}'.")
        except docker.errors.NotFound:
            logger.warning(f"Сеть '{DOCKER_AGENT_NETWORK_NAME}' не найдена. Контейнер будет запущен в сети Docker по умолчанию.")
        except Exception as e_net:
            logger.error(f"Ошибка при проверке сети '{DOCKER_AGENT_NETWORK_NAME}': {e_net}. Контейнер будет запущен в сети Docker по умолчанию.")
    try:
        log_params_display = {k: v for k, v in run_parameters.items() if k != "environment"}
        env_keys_to_log = [k for k, v in env_vars.items() if "PASSWORD" not in k.upper() and "HASH" not in k.upper() and "KEY" not in k.upper() and "STRING" not in k.upper()]
        log_params_display["env_keys"] = env_keys_to_log
        logger.debug(f"Попытка запуска контейнера '{container_name}' для сессии '{session_name}' с параметрами: {log_params_display}")
        container = DOCKER_CLIENT.containers.run(**run_parameters)
        logger.info(f"Контейнер {container.short_id} (имя: {container_name}) для сессии {session_name} успешно запущен.")
        await asyncio.sleep(2.5) 
        current_container = DOCKER_CLIENT.containers.get(container_name)
        is_active = (current_container.status == 'running')
        status_after_run = f"Docker: {current_container.status}"
        update_agent_status_in_config_file(session_name, status_after_run, is_active=is_active)
        if not is_active:
            logger.warning(f"Контейнер {container_name} для {session_name} после запуска имеет статус '{current_container.status}'. Проверьте логи контейнера.")
        return True 
    except Exception as e_run:
        logger.error(f"Критическая ошибка при запуске контейнера {session_name} (имя '{container_name}'): {e_run}", exc_info=True)
        update_agent_status_in_config_file(session_name, f"Ошибка Docker (запуск): {str(e_run)[:100]}", is_active=False)
        return False

@requires_docker
async def stop_agent_container(session_name: str, context: ContextTypes.DEFAULT_TYPE, remove_container_and_volume: bool = False) -> bool:
    if not DOCKER_CLIENT:
        logger.error(f"stop_agent_container для {session_name}: Docker клиент недоступен.")
        return False
    container_name = get_container_name(session_name)
    try:
        container = DOCKER_CLIENT.containers.get(container_name)
        logger.info(f"Остановка контейнера {container_name} для сессии {session_name}...")
        container.stop(timeout=10) 
        final_status_msg = get_container_status_message(container_name) 
        if remove_container_and_volume:
            logger.info(f"Удаление контейнера {container_name}...")
            container.remove() 
            volume_name = f"{container_name}_telethon_session"
            try:
                volume_to_remove = DOCKER_CLIENT.volumes.get(volume_name)
                volume_to_remove.remove(force=True) 
                logger.info(f"Volume '{volume_name}' для сессии {session_name} успешно удален.")
            except docker.errors.NotFound:
                logger.info(f"Volume '{volume_name}' для сессии {session_name} не найден при попытке удаления (возможно, уже удален или не создавался).")
            except Exception as e_vol_remove:
                 logger.warning(f"Не удалось удалить volume '{volume_name}' для сессии {session_name}: {e_vol_remove}")
            final_status_msg = "Остановлен и удален (Docker ресурсы)" 
        update_agent_status_in_config_file(session_name, final_status_msg, is_active=False)
        return True
    except docker.errors.NotFound:
        logger.info(f"Контейнер {container_name} для сессии {session_name} не найден при попытке остановки/удаления.")
        update_agent_status_in_config_file(session_name, "Не найден в Docker (при остановке/удалении)", is_active=False)
        return True 
    except Exception as e:
        logger.error(f"Ошибка Docker при остановке/удалении контейнера {container_name} для сессии {session_name}: {e}", exc_info=True)
        update_agent_status_in_config_file(session_name, f"Ошибка Docker (остановка/удаление): {str(e)[:50]}", is_active=None) 
        return False