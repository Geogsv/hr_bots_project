# admin_bot/handlers/conversation_add_agent.py
import re
from telegram import Update
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler, filters, CommandHandler
from telegram.constants import ParseMode
from config import logger, DOCKER_CLIENT, AGENT_DNS_LIST_GLOBAL
from auth import restricted, requires_docker
from redis_utils import load_agents_config, save_agents_config
from handlers.commands import show_agents_list_menu 
from constants import (
    ASK_SESSION_NAME, ASK_API_ID, ASK_API_HASH, ASK_SESSION_STRING, ASK_BOT_NAME,
    ASK_USE_PROXY, ASK_PROXY_TYPE, ASK_PROXY_HOST, ASK_PROXY_PORT, ASK_PROXY_USERNAME,
    ASK_PROXY_PASSWORD
)

@restricted
@requires_docker
async def add_agent_command_entry(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    if not update.message:
        return ConversationHandler.END
    await update.message.reply_text(
        "🤖 Добавление нового HR-Агента.\n\n"
        "Шаг 1: Введите **Уникальное Имя Сессии** для нового агента.\n"
        "Используйте только латинские буквы, цифры и символ подчеркивания `_`. Имя должно начинаться с буквы.\n"
        "Пример: `my_super_agent_1`\n\n"
        "Для отмены процесса в любой момент введите команду /cancel.",
        parse_mode=ParseMode.MARKDOWN
    )
    context.user_data['new_agent_data'] = {} 
    return ASK_SESSION_NAME

async def received_session_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    if not update.message or not update.message.text: return ASK_SESSION_NAME
    session_name_input = update.message.text.strip()
    if not (session_name_input and session_name_input[0].isalpha() and \
            all(c.isalnum() or c == '_' for c in session_name_input)):
        await update.message.reply_text(
            "⚠️ Имя сессии некорректно. Оно должно начинаться с латинской буквы и содержать только латинские буквы, цифры и '_'.\n"
            "Пожалуйста, введите имя сессии еще раз или используйте /cancel для отмены."
        )
        return ASK_SESSION_NAME
    if session_name_input in load_agents_config():
        await update.message.reply_text(
            f"⚠️ Агент с именем сессии `{session_name_input}` уже существует в конфигурации.\n"
            "Пожалуйста, выберите другое уникальное имя или используйте /cancel для отмены."
        )
        return ASK_SESSION_NAME
    context.user_data['new_agent_data']['session_name'] = session_name_input 
    await update.message.reply_text(
        f"✅ Имя сессии: `{session_name_input}`\n\n"
        "Шаг 2: Введите **API ID** вашего Telegram-приложения (числовое значение).\n"
        "Вы можете получить его на my.telegram.org.\n\n"
        "Отмена: /cancel.",
        parse_mode=ParseMode.MARKDOWN
    )
    return ASK_API_ID

async def received_api_id(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    if not update.message or not update.message.text: return ASK_API_ID
    try:
        api_id_input = int(update.message.text.strip())
        if api_id_input <= 0: raise ValueError("API ID должен быть положительным.")
    except ValueError:
        await update.message.reply_text(
            "⚠️ API ID должен быть целым положительным числом.\n"
            "Пожалуйста, введите API ID еще раз или /cancel."
        )
        return ASK_API_ID
    context.user_data['new_agent_data']['api_id'] = api_id_input 
    await update.message.reply_text(
        f"✅ API ID: `{api_id_input}`\n\n"
        "Шаг 3: Введите **API HASH** вашего Telegram-приложения (строка, обычно состоящая из ~32 шестнадцатеричных символов).\n"
        "Его также можно найти на my.telegram.org.\n\n"
        "Отмена: /cancel.",
        parse_mode=ParseMode.MARKDOWN
    )
    return ASK_API_HASH

async def received_api_hash(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    if not update.message or not update.message.text: return ASK_API_HASH
    api_hash_input = update.message.text.strip()
    if not (api_hash_input and len(api_hash_input) >= 30 and all(c in '0123456789abcdefABCDEF' for c in api_hash_input)):
        await update.message.reply_text(
            "⚠️ API HASH выглядит некорректно. Он должен состоять из шестнадцатеричных символов (0-9, a-f) и быть достаточной длины (обычно 32 символа).\n"
            "Пожалуйста, введите API HASH еще раз или /cancel."
        )
        return ASK_API_HASH
    context.user_data['new_agent_data']['api_hash'] = api_hash_input 
    await update.message.reply_text(
        "✅ API HASH получен.\n\n"
        "Шаг 4: Введите **строку сессии Telethon (Session String)**. Это ОБЯЗАТЕЛЬНЫЙ параметр для работы агента.\n"
        "Строку сессии нужно получить заранее, запустив скрипт генерации сессии для вашего аккаунта.\n\n"
        "Отмена: /cancel.",
        parse_mode=ParseMode.MARKDOWN
    )
    return ASK_SESSION_STRING

async def received_session_string(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    if not update.message or not update.message.text: return ASK_SESSION_STRING
    session_string_input = update.message.text.strip()
    if not session_string_input or len(session_string_input) < 50: 
        await update.message.reply_text(
            "⚠️ Строка сессии кажется слишком короткой или пустой. Она критически важна для работы агента.\n"
            "Пожалуйста, введите корректную строку сессии Telethon или /cancel."
        )
        return ASK_SESSION_STRING
    context.user_data['new_agent_data']['session_string'] = session_string_input 
    await update.message.reply_text(
        "✅ Строка сессии получена.\n\n"
        "Шаг 5: Введите **имя для агента, которое будет отображаться в чатах**. \n"
        "Если вы хотите, чтобы агент использовал имя из профиля Telegram-аккаунта, просто введите `-` (дефис).\n\n"
        "Отмена: /cancel.",
        parse_mode=ParseMode.MARKDOWN
    )
    return ASK_BOT_NAME

async def received_bot_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    if not update.message or not update.message.text: return ASK_BOT_NAME
    bot_name_override_input = update.message.text.strip()
    context.user_data['new_agent_data']['bot_name_override'] = bot_name_override_input if bot_name_override_input not in ['-', ''] else None 
    display_name_for_confirmation = bot_name_override_input if bot_name_override_input not in ['-',''] else 'Будет использовано имя из профиля Telegram'
    await update.message.reply_text(
        f"✅ Имя в чатах будет: `{display_name_for_confirmation}`\n\n"
        "Шаг 6: **Использовать прокси-сервер для этого агента?** (введите `да` или `нет`)\n\n"
        "Отмена: /cancel.",
        parse_mode=ParseMode.MARKDOWN
    )
    return ASK_USE_PROXY

async def received_use_proxy(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    if not update.message or not update.message.text: return ASK_USE_PROXY
    user_proxy_choice = update.message.text.strip().lower()
    if user_proxy_choice == 'да':
        context.user_data['new_agent_data']['proxy_config'] = {} 
        await update.message.reply_text(
            "Прокси будет настроен для этого агента.\n\n"
            "Шаг 6.1: Введите **тип прокси** (например, `socks5`, `socks4`, `http`).\n\n"
            "Отмена: /cancel.",
            parse_mode=ParseMode.MARKDOWN
        )
        return ASK_PROXY_TYPE
    elif user_proxy_choice == 'нет':
        context.user_data['new_agent_data']['proxy_config'] = None 
        await update.message.reply_text(
            "Прокси для этого агента использоваться не будет.\n"
            "DNS-серверы для агента будут взяты из глобальных настроек (.env), если они там указаны, или будут использоваться DNS Docker хоста по умолчанию.\n\n"
            "Все необходимые данные для конфигурации агента собраны. Сохраняю...",
            parse_mode=ParseMode.MARKDOWN
        )
        return await save_and_complete_agent_addition(update, context) 
    else:
        await update.message.reply_text(
            "⚠️ Некорректный ответ. Пожалуйста, введите 'да' или 'нет'.\n"
            "Или используйте /cancel для отмены."
        )
        return ASK_USE_PROXY

async def received_proxy_type(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    if not update.message or not update.message.text: return ASK_PROXY_TYPE
    proxy_type_input = update.message.text.strip().lower()
    allowed_proxy_types = ['socks5', 'socks4', 'http']
    if proxy_type_input not in allowed_proxy_types:
        await update.message.reply_text(
            f"⚠️ Неверный тип прокси. Допустимые значения: {', '.join(allowed_proxy_types)}.\n"
            "Пожалуйста, введите тип еще раз или /cancel."
        )
        return ASK_PROXY_TYPE
    context.user_data['new_agent_data']['proxy_config']['type'] = proxy_type_input 
    await update.message.reply_text(
        f"✅ Тип прокси: `{proxy_type_input}`\n\n"
        "Шаг 6.2: Введите **хост прокси-сервера** (IP-адрес или доменное имя).\n"
        "Пример: `123.45.67.89` или `proxy.example.com`\n\n"
        "Отмена: /cancel.",
        parse_mode=ParseMode.MARKDOWN
    )
    return ASK_PROXY_HOST

async def received_proxy_host(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    if not update.message or not update.message.text: return ASK_PROXY_HOST
    proxy_host_input = update.message.text.strip()
    host_pattern = re.compile(
        r"^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$"
        r"|^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*"
        r"([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])$" 
    )
    if not host_pattern.match(proxy_host_input):
        await update.message.reply_text(
            "⚠️ Некорректный формат хоста прокси. Это должен быть действительный IP-адрес или доменное имя.\n"
            "Пожалуйста, введите хост еще раз или /cancel."
        )
        return ASK_PROXY_HOST
    context.user_data['new_agent_data']['proxy_config']['host'] = proxy_host_input 
    await update.message.reply_text(
        f"✅ Хост прокси: `{proxy_host_input}`\n\n"
        "Шаг 6.3: Введите **порт прокси-сервера** (число от 1 до 65535).\n\n"
        "Отмена: /cancel.",
        parse_mode=ParseMode.MARKDOWN
    )
    return ASK_PROXY_PORT

async def received_proxy_port(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    if not update.message or not update.message.text: return ASK_PROXY_PORT
    try:
        proxy_port_input = int(update.message.text.strip())
        if not (1 <= proxy_port_input <= 65535):
            raise ValueError("Порт вне допустимого диапазона.")
    except ValueError:
        await update.message.reply_text(
            "⚠️ Порт прокси должен быть целым числом в диапазоне от 1 до 65535.\n"
            "Пожалуйста, введите порт еще раз или /cancel."
        )
        return ASK_PROXY_PORT
    context.user_data['new_agent_data']['proxy_config']['port'] = proxy_port_input 
    await update.message.reply_text(
        f"✅ Порт прокси: `{proxy_port_input}`\n\n"
        "Шаг 6.4: Введите **имя пользователя для аутентификации на прокси-сервере**. \n"
        "Если аутентификация не требуется, просто введите `-` (дефис).\n\n"
        "Отмена: /cancel.",
        parse_mode=ParseMode.MARKDOWN
    )
    return ASK_PROXY_USERNAME

async def received_proxy_username(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    if not update.message or not update.message.text: return ASK_PROXY_USERNAME
    proxy_username_input = update.message.text.strip()
    context.user_data['new_agent_data']['proxy_config']['username'] = proxy_username_input if proxy_username_input not in ['-', ''] else None 
    username_display_confirm = proxy_username_input if proxy_username_input not in ['-',''] else 'Не указано (аутентификация не будет использоваться)'
    await update.message.reply_text(
        f"✅ Имя пользователя для прокси: `{username_display_confirm}`\n\n"
        "Шаг 6.5: Введите **пароль для аутентификации на прокси-сервере**. \n"
        "Если имя пользователя не было указано или пароль не требуется, просто введите `-` (дефис).\n\n"
        "Отмена: /cancel.",
        parse_mode=ParseMode.MARKDOWN
    )
    return ASK_PROXY_PASSWORD

async def received_proxy_password(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    if not update.message or not update.message.text: return ASK_PROXY_PASSWORD
    proxy_password_input = update.message.text.strip()
    if context.user_data['new_agent_data']['proxy_config'].get('username'): 
        context.user_data['new_agent_data']['proxy_config']['password'] = proxy_password_input if proxy_password_input not in ['-', ''] else None 
    else: 
        context.user_data['new_agent_data']['proxy_config']['password'] = None 
    await update.message.reply_text(
        "✅ Данные для прокси-сервера получены.\n"
        "DNS-серверы для агента будут взяты из глобальных настроек (.env), если они там указаны, или будут использоваться DNS Docker хоста по умолчанию.\n\n"
        "Все необходимые данные для конфигурации агента собраны. Сохраняю...",
        parse_mode=ParseMode.MARKDOWN
    )
    return await save_and_complete_agent_addition(update, context) 

async def save_and_complete_agent_addition(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not update.message: return ConversationHandler.END
    agent_data_collected = context.user_data.get('new_agent_data', {}) 
    session_name_final = agent_data_collected.get('session_name')
    if not all([
        session_name_final,
        agent_data_collected.get('api_id'),
        agent_data_collected.get('api_hash'),
        agent_data_collected.get('session_string') 
    ]):
        await update.message.reply_text(
            "⚠️ Ошибка: не все ОБЯЗАТЕЛЬНЫЕ данные (имя сессии, API ID, API HASH, строка сессии) были корректно собраны.\n"
            "Пожалуйста, начните процесс добавления агента заново с помощью команды /add_agent."
        )
        context.user_data.clear() 
        return ConversationHandler.END
    new_agent_final_config = {
        "api_id": agent_data_collected['api_id'],
        "api_hash": agent_data_collected['api_hash'],
        "session_string": agent_data_collected['session_string'],
        "bot_name_override": agent_data_collected.get('bot_name_override'), 
        "proxy_config": agent_data_collected.get('proxy_config'),       
        "is_active": False, 
        "status_message": "Только что добавлен, ожидает первого запуска"
    }
    all_agents_configs = load_agents_config()
    all_agents_configs[session_name_final] = new_agent_final_config 
    save_agents_config(all_agents_configs)
    proxy_info_for_user = "не используется"
    if new_agent_final_config["proxy_config"]:
        p_conf = new_agent_final_config["proxy_config"]
        proxy_info_for_user = f"{p_conf.get('type','N/A')}://{p_conf.get('host','N/A')}:{p_conf.get('port','N/A')}"
        if p_conf.get('username'): 
            proxy_info_for_user += " (с аутентификацией)"
    dns_info_for_user = "будут использованы DNS Docker хоста по умолчанию"
    if AGENT_DNS_LIST_GLOBAL: 
        dns_info_for_user = f"будут использованы глобальные DNS из .env: {', '.join(AGENT_DNS_LIST_GLOBAL)}"
    await update.message.reply_text(
        f"✅ HR-Агент с именем сессии `{session_name_final}` успешно добавлен в конфигурацию!\n\n"
        f"Прокси для этого агента: `{proxy_info_for_user}`.\n"
        f"DNS для этого агента: `{dns_info_for_user}`.\n"
        f"Текущий статус: Ожидает первого запуска.\n\n"
        "Теперь вы можете найти этого агента в общем списке и управлять им оттуда.",
        parse_mode=ParseMode.MARKDOWN
    )
    context.user_data.clear() 
    await show_agents_list_menu(update, context, edit_message=False) 
    return ConversationHandler.END

async def cancel_add_agent(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not update.message: return ConversationHandler.END
    await update.message.reply_text("Процесс добавления нового HR-Агента отменен.")
    context.user_data.clear() 
    await show_agents_list_menu(update, context, edit_message=False) 
    return ConversationHandler.END