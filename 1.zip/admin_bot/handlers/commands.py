# admin_bot/handlers/commands.py
from telegram import Update, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from config import logger, DOCKER_CLIENT, admin_redis_client, AGENT_DNS_LIST_GLOBAL
from auth import restricted
from redis_utils import load_agents_config, update_agent_status_in_config_file
from docker_utils import get_container_name, get_container_status_message
from constants import ACTION_MAIN_MENU

@restricted
async def start_panel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from ui.keyboards import get_main_menu_keyboard # Динамический импорт
    user = update.effective_user
    if not user: 
        logger.warning("start_panel_command вызван без effective_user.")
        return
    logger.info(f"Пользователь {user.id} ({user.first_name}) открыл панель управления.")
    reply_markup = await get_main_menu_keyboard(context) 
    text = f"👋 Привет, {user.first_name}! Добро пожаловать в панель управления HR-Агентами."
    if not DOCKER_CLIENT:
        text += "\n\n⚠️ Docker клиент недоступен. Функционал управления контейнерами агентов будет ограничен."
    if not admin_redis_client: 
        text += "\n\n⚠️ Redis клиент недоступен. Функционал будет серьезно ограничен или невозможен."
    if update.callback_query and update.callback_query.data == ACTION_MAIN_MENU:
        try:
            await update.callback_query.edit_message_text(text=text, reply_markup=reply_markup)
        except Exception as e: 
            logger.debug(f"Незначительная ошибка при edit_message_text в start_panel_command: {e}")
            await update.callback_query.answer() 
    elif update.message:
        await update.message.reply_text(text, reply_markup=reply_markup)

async def show_agents_list_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, edit_message: bool = True):
    from ui.keyboards import get_agents_list_layout # Динамический импорт
    query = update.callback_query
    if query:
        await query.answer("Обновляю список агентов...")
    agents = load_agents_config()
    if DOCKER_CLIENT: 
        changed_in_sync = False
        for session_name_sync, agent_config_sync in list(agents.items()):
            container_name_sync = get_container_name(session_name_sync)
            actual_status_msg = get_container_status_message(container_name_sync)
            is_actually_running = "running" in actual_status_msg.lower()
            if agent_config_sync.get("status_message") != actual_status_msg or \
               agent_config_sync.get("is_active") != is_actually_running:
                update_agent_status_in_config_file(session_name_sync, actual_status_msg, is_active=is_actually_running)
                changed_in_sync = True
        if changed_in_sync: 
            agents = load_agents_config()
    text_response = "📋 Список зарегистрированных HR-Агентов:\n\n" if agents else "Список HR-Агентов в настоящее время пуст."
    is_main_menu_context = False
    if update.message and update.message.text:
        is_main_menu_context = update.message.text in ["/start", "/panel"]
    elif query and query.data:
         is_main_menu_context = query.data == ACTION_MAIN_MENU
    kbd_layout_buttons = get_agents_list_layout(agents, is_main_menu_context)
    reply_markup_response = InlineKeyboardMarkup(kbd_layout_buttons)
    try:
        if query and edit_message:
            await query.edit_message_text(text_response, reply_markup=reply_markup_response, parse_mode=ParseMode.MARKDOWN)
        elif update.message:
            await update.message.reply_text(text_response, reply_markup=reply_markup_response, parse_mode=ParseMode.MARKDOWN)
        elif query and not edit_message:
            if query.message: 
                 await context.bot.send_message(
                     query.message.chat_id, 
                     text_response, 
                     reply_markup=reply_markup_response, 
                     parse_mode=ParseMode.MARKDOWN
                 )
            else: 
                logger.warning("Попытка отправить список агентов через query без query.message")
    except Exception as e:
        logger.warning(f"Ошибка при обновлении/отправке списка агентов: {e}", exc_info=True)
        if query: await query.answer("Произошла ошибка при отображении списка.")

@restricted
async def list_agents_command_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_agents_list_menu(update, context, edit_message=False)

async def show_agent_management_menu_content(update: Update, context: ContextTypes.DEFAULT_TYPE, session_name: str):
    from ui.keyboards import get_agent_management_keyboard # Динамический импорт
    query = update.callback_query
    agents_data = load_agents_config()
    agent_specific_config = agents_data.get(session_name)
    if not agent_specific_config:
        if query: await query.answer("Агент с таким именем не найден в конфигурации.", show_alert=True)
        await show_agents_list_menu(update, context) 
        return
    if DOCKER_CLIENT:
        container_name_detail = get_container_name(session_name)
        actual_docker_status_msg = get_container_status_message(container_name_detail)
        is_docker_running = "running" in actual_docker_status_msg.lower()
        if agent_specific_config.get("status_message") != actual_docker_status_msg or \
           agent_specific_config.get("is_active") != is_docker_running:
            update_agent_status_in_config_file(session_name, actual_docker_status_msg, is_active=is_docker_running)
            agent_specific_config = load_agents_config().get(session_name) 
            if not agent_specific_config: 
                if query: await query.answer("Агент был удален во время обновления статуса.", show_alert=True)
                await show_agents_list_menu(update, context)
                return
    is_agent_active = agent_specific_config.get("is_active", False)
    current_status_msg = agent_specific_config.get("status_message", "N/A").replace("Docker: ", "")
    status_icon = "🟢" if is_agent_active else \
                  ("🔴" if "не найден" not in current_status_msg.lower() and \
                             "остановлен" not in current_status_msg.lower() and \
                             "exited" not in current_status_msg.lower() else \
                   ("⚪️" if "не найден" in current_status_msg.lower() else "⚫️")) 
    detail_text = f"🛠️ Управление агентом: `{session_name}`\n"
    detail_text += f"Текущий статус: {status_icon} *{current_status_msg}*\n\n"
    detail_text += f"API ID: `{agent_specific_config.get('api_id', 'Не указан')}`\n"
    detail_text += f"Имя в чатах (override): `{agent_specific_config.get('bot_name_override', 'Используется из профиля Telegram')}`\n"
    detail_text += f"Строка сессии: `{'Присутствует' if agent_specific_config.get('session_string') else 'Отсутствует (КРИТИЧНО!)'}`\n"
    proxy_config_data = agent_specific_config.get("proxy_config")
    proxy_display_info = "Не настроен"
    if proxy_config_data and isinstance(proxy_config_data, dict):
        proxy_display_info = f"{proxy_config_data.get('type', 'N/A')}://{proxy_config_data.get('host', 'N/A')}:{proxy_config_data.get('port', 'N/A')}"
        if proxy_config_data.get("username"): proxy_display_info += " (с аутентификацией)"
    detail_text += f"Прокси: `{proxy_display_info}`\n"
    dns_info_display = "Используются DNS Docker хоста по умолчанию"
    if AGENT_DNS_LIST_GLOBAL: 
        dns_info_display = f"Глобальные из .env: {', '.join(AGENT_DNS_LIST_GLOBAL)}"
    detail_text += f"DNS (глобальные для всех агентов): `{dns_info_display}`\n"
    management_keyboard = get_agent_management_keyboard(session_name, is_agent_active)
    if query:
        try:
            await query.edit_message_text(detail_text, reply_markup=management_keyboard, parse_mode=ParseMode.MARKDOWN)
        except Exception as e_edit:
            logger.debug(f"Незначительная ошибка при обновлении меню управления агентом {session_name}: {e_edit}")
            await query.answer()