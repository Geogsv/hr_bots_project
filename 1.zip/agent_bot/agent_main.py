# agent_bot/agent_main.py
import asyncio
import random
import python_socks # type: ignore
from telethon import TelegramClient, events # type: ignore
from telethon.sessions import StringSession # type: ignore
from telethon.errors import ( # type: ignore
    UserNotParticipantError, ChannelPrivateError, ChatWriteForbiddenError,
    UserIsBlockedError, FloodWaitError, AuthKeyError, UnauthorizedError, UserDeactivatedError, SessionExpiredError
)
import redis # Для redis.exceptions
from config import (
    logger, TELEGRAM_API_ID, TELEGRAM_API_HASH, TELEGRAM_SESSION_STRING,
    TELEGRAM_SESSION_NAME, REDIS_HOST, REDIS_PORT,
    TELETHON_PROXY_SETTINGS, CURRENT_BOT_NAME, redis_client, gemini_model, BOT_NAME_FROM_ENV
)
from message_handler import handle_user_message

client: TelegramClient | None = None
bot_dynamic_name: str | None = CURRENT_BOT_NAME

async def run_agent():
    global client, bot_dynamic_name
    if not redis_client:
        logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}' не может запуститься без Redis. Проверьте конфигурацию Redis.")
        return
    if not gemini_model:
        logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}' не может запуститься без Gemini. Проверьте конфигурацию Gemini.")
        return
    if not TELEGRAM_SESSION_STRING:
        logger.critical(f"КРИТИКА: TELEGRAM_SESSION_STRING не предоставлена для агента '{TELEGRAM_SESSION_NAME}'. Агент не может запуститься.")
        return
    if not TELEGRAM_API_ID or not TELEGRAM_API_HASH or not TELEGRAM_SESSION_NAME:
        logger.critical(f"КРИТИКА: TELEGRAM_API_ID, HASH или SESSION_NAME не установлены для агента. Агент не может запуститься.")
        return
    logger.info(f"Запуск логики агента '{TELEGRAM_SESSION_NAME}'...")
    session_to_use = StringSession(TELEGRAM_SESSION_STRING)
    proxy_arg_for_telethon = None
    if TELETHON_PROXY_SETTINGS:
        proxy_arg_for_telethon = (
            TELETHON_PROXY_SETTINGS["proxy_type"], TELETHON_PROXY_SETTINGS["addr"],
            TELETHON_PROXY_SETTINGS["port"], TELETHON_PROXY_SETTINGS["rdns"],
            TELETHON_PROXY_SETTINGS["username"], TELETHON_PROXY_SETTINGS["password"]
        )
    client = TelegramClient(session_to_use, TELEGRAM_API_ID, TELEGRAM_API_HASH, proxy=proxy_arg_for_telethon)
    logger.info("Клиент Telethon инициализирован" + (" с прокси." if proxy_arg_for_telethon else "."))

    @client.on(events.NewMessage(incoming=True, forwards=False))
    async def new_message_listener(event: events.NewMessage.Event):
        global bot_dynamic_name # client будет доступен из замыкания run_agent
        if not client or not client.is_connected(): # ИСПРАВЛЕНО: client.is_connected() - синхронный
            logger.warning(f"Получено сообщение для агента '{TELEGRAM_SESSION_NAME}', но клиент Telethon не активен/не подключен.")
            return
        if event.is_private and not event.message.out:
            user_id = event.sender_id
            message_text = event.text.strip() if event.text else ""
            logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Получено сообщение от пользователя {user_id}: '{message_text[:50]}...'")
            if bot_dynamic_name is None:
                try:
                    me = await client.get_me()
                    if me:
                        bot_dynamic_name = me.first_name + (f" {me.last_name}" if me.last_name else "")
                        logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Имя бота установлено из профиля: {bot_dynamic_name}")
                    else:
                        bot_dynamic_name = f"Ассистент {TELEGRAM_SESSION_NAME}"
                        logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Не удалось получить 'me' из профиля. Используется запасное имя: {bot_dynamic_name}")
                except Exception as e_me:
                    bot_dynamic_name = f"Ассистент {TELEGRAM_SESSION_NAME}"
                    logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка при получении имени бота из профиля: {e_me}. Используется запасное имя: {bot_dynamic_name}", exc_info=True)

            current_effective_bot_name = bot_dynamic_name or f"Ассистент {TELEGRAM_SESSION_NAME}"
            bot_reply_text = await handle_user_message(user_id, message_text, current_effective_bot_name)

            if bot_reply_text:
                await asyncio.sleep(random.uniform(1.0, 2.5))
                try:
                    await event.respond(bot_reply_text)
                    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Ответ для пользователя {user_id} отправлен: '{bot_reply_text[:50]}...'")
                except (ChatWriteForbiddenError, UserIsBlockedError) as e_perm:
                    logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Не удалось отправить сообщение пользователю {user_id} (блок/запрет): {e_perm}")
                except FloodWaitError as e_flood:
                    wait_time = e_flood.seconds + random.randint(1,3)
                    logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': FloodWait при отправке пользователю {user_id}. Ожидание {wait_time} сек.")
                    await asyncio.sleep(wait_time)
                    try:
                        await event.respond(bot_reply_text)
                        logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Сообщение пользователю {user_id} успешно отправлено после FloodWait.")
                    except Exception as e_retry:
                        logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка повторной отправки сообщения пользователю {user_id} после FloodWait: {e_retry}", exc_info=True)
                except Exception as e_send:
                    logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Общая ошибка при отправке сообщения пользователю {user_id}: {e_send}", exc_info=True)
            else:
                logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Сгенерирован пустой ответ для пользователя {user_id}, отправка не будет произведена.")
    try:
        logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Попытка подключения к Telegram (используется строка сессии)...")
        if not client:
             logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': Клиент Telethon не был инициализирован перед connect().")
             return
        await client.connect()
        if not client.is_connected(): # <--- ИСПРАВЛЕНО
            logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': Не удалось подключиться к Telegram после client.connect(). Остановка.")
            if client: # Попытка корректного отключения, если клиент был создан
                try:
                    await client.disconnect()
                except Exception as e_disc:
                    logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка при попытке отключения клиента после неудачного connect: {e_disc}")
            return
        if not client.is_user_authorized(): # <--- ИСПРАВЛЕНО
            logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': АВТОРИЗАЦИЯ НЕ УДАЛАСЬ. Строка сессии недействительна или отозвана. Остановка агента.")
            if client: # Попытка корректного отключения
                try:
                    if client.is_connected(): # Отключаемся только если подключены
                       await client.disconnect()
                except Exception as e_disc:
                    logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка при попытке отключения клиента после неудачной авторизации: {e_disc}")
            return

        final_bot_name_to_log = BOT_NAME_FROM_ENV
        if not final_bot_name_to_log:
            if bot_dynamic_name is None: # Если имя еще не было получено
                try:
                    me = await client.get_me()
                    if me:
                        bot_dynamic_name = me.first_name + (f" {me.last_name}" if me.last_name else "")
                    else: # Маловероятно, если авторизация прошла
                        bot_dynamic_name = f"Ассистент {TELEGRAM_SESSION_NAME}"
                except Exception as e_me_late:
                    logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка при получении имени бота (поздняя попытка): {e_me_late}. Используется запасное имя.")
                    bot_dynamic_name = f"Ассистент {TELEGRAM_SESSION_NAME}"
            final_bot_name_to_log = bot_dynamic_name
        # Обновляем CURRENT_BOT_NAME в config для согласованности, если оно было установлено из профиля
        # Это изменение в config не повлияет на уже импортированные значения в других модулях,
        # поэтому передача имени бота как параметра в функции message_handler более надежна.
        # from config import CURRENT_BOT_NAME as cfg_bot_name_ref_main # type: ignore
        # if cfg_bot_name_ref_main != final_bot_name_to_log:
            # pass
        logger.info(f"Агент '{final_bot_name_to_log}' (сессия: {TELEGRAM_SESSION_NAME}) успешно авторизован и запущен. Redis: {REDIS_HOST}:{REDIS_PORT}. Ожидание сообщений...")
        await client.run_until_disconnected()
    except (AuthKeyError, SessionExpiredError, UserDeactivatedError, UnauthorizedError) as e_auth_critical:
        logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': КРИТИЧЕСКАЯ ОШИБКА АВТОРИЗАЦИИ/СЕССИИ: {type(e_auth_critical).__name__} - {e_auth_critical}. Обновите строку сессии. Агент будет остановлен.", exc_info=True)
    except (ConnectionRefusedError, OSError, python_socks.ProxyConnectionError, python_socks.ProxyError) as e_conn_critical: # type: ignore
        logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': КРИТИЧЕСКАЯ ОШИБКА СЕТИ/ПРОКСИ: {type(e_conn_critical).__name__} - {e_conn_critical}. Проверьте сетевое подключение, настройки прокси и DNS. Агент будет остановлен.", exc_info=True)
    except redis.exceptions.ConnectionError as e_redis_main:
        logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': КРИТИЧЕСКАЯ ОШИБКА Redis в основном потоке: {e_redis_main}. Агент будет остановлен.", exc_info=True)
    except Exception as e_global:
        logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': Непредвиденная КРИТИЧЕСКАЯ ошибка в основном цикле `run_agent`: {type(e_global).__name__} - {e_global}. Агент будет остановлен.", exc_info=True)
    finally:
        if client and client.is_connected(): # ИСПРАВЛЕНО: client.is_connected() - синхронный
            logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Отключение от Telegram...")
            try:
                await client.disconnect()
            except Exception as e_disc_final:
                 logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка при финальном отключении клиента: {e_disc_final}")
        logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Процесс Telethon остановлен.")

if __name__ == '__main__':
    initial_display_name = CURRENT_BOT_NAME or f"Ассистент ({TELEGRAM_SESSION_NAME or 'Unknown'})"
    logger.info(f"Запуск экземпляра агента '{TELEGRAM_SESSION_NAME or 'Unknown'}' с начальным отображаемым именем '{initial_display_name}' через __main__...")
    try:
        asyncio.run(run_agent())
    except KeyboardInterrupt:
        logger.info(f"Агент '{TELEGRAM_SESSION_NAME or 'Unknown'}': Получен сигнал KeyboardInterrupt (Ctrl+C). Завершение работы...")
    except Exception as e_async_run:
        logger.critical(f"Агент '{TELEGRAM_SESSION_NAME or 'Unknown'}': Неперехваченная ошибка на уровне asyncio.run: {e_async_run}", exc_info=True)
    finally:
        logger.info(f"Агент '{TELEGRAM_SESSION_NAME or 'Unknown'}': Процесс завершен.")