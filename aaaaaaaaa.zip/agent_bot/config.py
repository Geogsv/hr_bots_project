import logging
import os
import python_socks # type: ignore
from dotenv import load_dotenv
import google.generativeai as genai
import redis

# --- Загрузка переменных окружения (для локального запуска) ---
dotenv_path = os.path.join(os.path.dirname(__file__), '.env')

_early_session_name_for_log = os.getenv('TELEGRAM_SESSION_NAME', 'agent_early_init')

if os.path.exists(dotenv_path):
    load_dotenv(dotenv_path)
    _early_session_name_for_log = os.getenv('TELEGRAM_SESSION_NAME', _early_session_name_for_log)
    print(f"[Agent {_early_session_name_for_log}] Загружен локальный .env файл: {dotenv_path}")
else:
    print(f"[Agent {_early_session_name_for_log}] Файл {dotenv_path} не найден. Используются переменные окружения системы/Docker.")


# --- Объявление переменных конфигурации с типами и значениями по умолчанию ---
TELEGRAM_API_ID: int | None = None
TELEGRAM_API_HASH: str | None = None
TELEGRAM_SESSION_NAME: str | None = None 
GEMINI_API_KEY: str | None = None
TELEGRAM_SESSION_STRING: str | None = None
GEMINI_MODEL_NAME: str = 'gemini-1.5-flash-latest' 
BOT_NAME_FROM_ENV: str | None = None 
AGENT_LOG_LEVEL_STR: str = 'INFO' 
REDIS_HOST: str = 'redis' 
_redis_port_str_default: str = '6379'
REDIS_PORT: int = 6379 
_user_state_ttl_default: str = str(14 * 24 * 60 * 60) # 14 дней в секундах (увеличено для напоминаний)
USER_STATE_TTL_SECONDS: int = int(_user_state_ttl_default) 

COMPANY_NAME: str = "ООО 'Перспектива Роста'" # Значение по умолчанию
COMPANY_CITY: str = "г. Москва" # Значение по умолчанию
DAILY_REMINDER_ENABLED_STR: str = 'true' # Значение по умолчанию
DAILY_REMINDER_ENABLED: bool = True


# Telethon Proxy Settings Dictionary
TELETHON_PROXY_SETTINGS: dict | None = None


# --- Чтение и валидация конфигурации ---
try:
    _api_id_env_str = os.getenv('TELEGRAM_API_ID')
    if not _api_id_env_str: raise ValueError("Переменная окружения TELEGRAM_API_ID не установлена или пуста.")
    TELEGRAM_API_ID = int(_api_id_env_str)

    TELEGRAM_API_HASH = os.getenv('TELEGRAM_API_HASH')
    TELEGRAM_SESSION_NAME = os.getenv('TELEGRAM_SESSION_NAME') 
    GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')
    TELEGRAM_SESSION_STRING = os.getenv('TELEGRAM_SESSION_STRING') 

    GEMINI_MODEL_NAME = os.getenv('GEMINI_MODEL_NAME', GEMINI_MODEL_NAME) 
    BOT_NAME_FROM_ENV = os.getenv('BOT_NAME_OVERRIDE') 
    AGENT_LOG_LEVEL_STR = os.getenv('LOG_LEVEL', AGENT_LOG_LEVEL_STR).upper()
    REDIS_HOST = os.getenv('REDIS_HOST', REDIS_HOST)

    _redis_port_env_str = os.getenv('REDIS_PORT', _redis_port_str_default)
    if not _redis_port_env_str or not _redis_port_env_str.isdigit():
        raise ValueError(f"REDIS_PORT ('{_redis_port_env_str}') должен быть числом.")
    REDIS_PORT = int(_redis_port_env_str)

    _user_state_ttl_env_str = os.getenv('USER_STATE_TTL_SECONDS', _user_state_ttl_default)
    if not _user_state_ttl_env_str or not _user_state_ttl_env_str.isdigit():
        raise ValueError(f"USER_STATE_TTL_SECONDS ('{_user_state_ttl_env_str}') должен быть числом.")
    USER_STATE_TTL_SECONDS = int(_user_state_ttl_env_str)

    COMPANY_NAME = os.getenv('COMPANY_NAME', COMPANY_NAME)
    COMPANY_CITY = os.getenv('COMPANY_CITY', COMPANY_CITY)
    DAILY_REMINDER_ENABLED_STR = os.getenv('DAILY_REMINDER_ENABLED', DAILY_REMINDER_ENABLED_STR)
    DAILY_REMINDER_ENABLED = DAILY_REMINDER_ENABLED_STR.lower() == 'true'


    _proxy_type_env_str = os.getenv('TELETHON_PROXY_TYPE')
    _proxy_host_env = os.getenv('TELETHON_PROXY_HOST')
    _proxy_port_env_str = os.getenv('TELETHON_PROXY_PORT')
    
    if _proxy_host_env and _proxy_port_env_str and _proxy_type_env_str:
        if not _proxy_port_env_str.isdigit():
            raise ValueError(f"TELETHON_PROXY_PORT ('{_proxy_port_env_str}') должен быть числом.")
        _proxy_port_val = int(_proxy_port_env_str)
        _proxy_username_env = os.getenv('TELETHON_PROXY_USERNAME')
        _proxy_password_env = os.getenv('TELETHON_PROXY_PASSWORD')
        
        proxy_type_map = {
            'socks5': python_socks.ProxyType.SOCKS5,
            'socks4': python_socks.ProxyType.SOCKS4,
            'http': python_socks.ProxyType.HTTP,
        }
        selected_proxy_type_val = proxy_type_map.get(_proxy_type_env_str.lower())

        if selected_proxy_type_val:
            rdns_val = True if selected_proxy_type_val in [python_socks.ProxyType.SOCKS5, python_socks.ProxyType.SOCKS4] else False
            TELETHON_PROXY_SETTINGS = {
                "proxy_type": selected_proxy_type_val,
                "addr": _proxy_host_env,
                "port": _proxy_port_val,
                "rdns": rdns_val,
                "username": _proxy_username_env or None, 
                "password": _proxy_password_env or None  
            }
        else:
            print(f"[Agent Config {_early_session_name_for_log}] Указан неизвестный тип прокси '{_proxy_type_env_str}'. Прокси не будет использован.")
    
except (TypeError, ValueError) as e_config:
    current_session_name_for_error_log = TELEGRAM_SESSION_NAME or _early_session_name_for_log
    problematic_values_for_debug = {
        "TELEGRAM_API_ID": os.getenv('TELEGRAM_API_ID'),
        "REDIS_PORT": os.getenv('REDIS_PORT'),
        "USER_STATE_TTL_SECONDS": os.getenv('USER_STATE_TTL_SECONDS'),
        "TELETHON_PROXY_PORT": os.getenv('TELETHON_PROXY_PORT') 
    }
    print(f"Критическая ошибка [Agent Config {current_session_name_for_error_log}]: Неверный тип или значение переменной окружения: {e_config}. "
          f"Значения потенциально проблемных переменных: {problematic_values_for_debug}")
    exit(1) 

critical_env_vars_check = {
    "TELEGRAM_API_ID": TELEGRAM_API_ID,
    "TELEGRAM_API_HASH": TELEGRAM_API_HASH,
    "TELEGRAM_SESSION_NAME": TELEGRAM_SESSION_NAME, 
    "GEMINI_API_KEY": GEMINI_API_KEY,
}
missing_vars_list_check = [name for name, value in critical_env_vars_check.items() if not value] 

if missing_vars_list_check:
    current_session_name_for_error_log = TELEGRAM_SESSION_NAME or _early_session_name_for_log
    print(f"Критическая ошибка [Agent Config {current_session_name_for_error_log}]: Следующие обязательные переменные окружения не установлены или пусты: {', '.join(missing_vars_list_check)}")
    exit(1)

agent_numeric_log_level_val = getattr(logging, AGENT_LOG_LEVEL_STR, logging.INFO)
logger = logging.getLogger(f"Agent_{TELEGRAM_SESSION_NAME}") 
logger.setLevel(agent_numeric_log_level_val)

if not logger.hasHandlers(): 
    log_formatter_val = logging.Formatter(f'[%(levelname)5s/%(asctime)s] %(name)s: %(message)s')
    stream_handler_val = logging.StreamHandler()
    stream_handler_val.setFormatter(log_formatter_val)
    logger.addHandler(stream_handler_val)
    logger.propagate = False 

logger.info(f"Уровень логирования для агента '{TELEGRAM_SESSION_NAME}': {AGENT_LOG_LEVEL_STR}")
logger.info(f"Компания: {COMPANY_NAME}, Город офиса: {COMPANY_CITY}")
logger.info(f"Ежедневные напоминания кандидатам: {'Включены' if DAILY_REMINDER_ENABLED else 'Отключены'}")

if TELETHON_PROXY_SETTINGS:
    proxy_info_log = (
        f"{TELETHON_PROXY_SETTINGS['proxy_type'].name}://"
        f"{TELETHON_PROXY_SETTINGS['addr']}:{TELETHON_PROXY_SETTINGS['port']} "
        f"(RDNS: {TELETHON_PROXY_SETTINGS['rdns']})"
    )
    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}' будет использовать прокси: {proxy_info_log}")


redis_client: redis.StrictRedis | None = None
try:
    redis_client = redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=0, decode_responses=False) 
    redis_client.ping()
    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Успешное подключение к Redis: {REDIS_HOST}:{REDIS_PORT}")
except redis.exceptions.ConnectionError as e_redis_conn:
    logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': КРИТИЧЕСКАЯ ОШИБКА - Redis недоступен ({REDIS_HOST}:{REDIS_PORT}): {e_redis_conn}", exc_info=True)
    redis_client = None 


gemini_model: genai.GenerativeModel | None = None
try:
    if not GEMINI_API_KEY: 
        raise ValueError("GEMINI_API_KEY не установлен.")
    genai.configure(api_key=GEMINI_API_KEY)
    gemini_model = genai.GenerativeModel(GEMINI_MODEL_NAME)
    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Модель Gemini '{GEMINI_MODEL_NAME}' успешно инициализирована.")
except Exception as e_gemini_init:
    logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': КРИТИЧЕСКАЯ ОШИБКА - Gemini не инициализирован: {e_gemini_init}", exc_info=True)
    gemini_model = None 

CURRENT_BOT_NAME: str | None = BOT_NAME_FROM_ENV