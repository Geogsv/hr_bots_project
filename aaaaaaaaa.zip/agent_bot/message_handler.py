import google.generativeai as genai
from google.generativeai.types import HarmCategory, HarmBlockThreshold
from datetime import datetime, date, timezone
import re
from typing import Tuple

from config import logger, gemini_model, TELEGRAM_SESSION_NAME, COMPANY_NAME, COMPANY_CITY
from constants import (
    SCENARIO, IMPROVED_SYSTEM_PROMPT_TEMPLATE, BAD_WORDS,
)
from state_manager import (
    get_user_state, save_user_state, add_to_chat_history,
    update_anketa_answer, advance_user_stage,
    increment_profanity_strike
)

def contains_profanity(text: str) -> bool:
    if not text:
        return False
    text_lower = text.lower()
    for word in BAD_WORDS:
        if word in text_lower:
            return True
    return False

def parse_dob(dob_str: str) -> date | None:
    formats_to_try = ["%d.%m.%Y", "%d-%m-%Y", "%d/%m/%Y", "%Y.%m.%d", "%Y-%m-%d", "%Y/%m/%d"]
    for fmt in formats_to_try:
        try:
            return datetime.strptime(dob_str, fmt).date()
        except ValueError:
            continue
    dob_str_parts = re.split(r'[.\-/\s]+', dob_str)
    if len(dob_str_parts) == 3:
        try:
            d, m, y = -1, -1, -1
            parts_int = [int(p) for p in dob_str_parts]

            if parts_int[0] > 31 : 
                y,m,d = parts_int[0], parts_int[1], parts_int[2]
            elif parts_int[2] > 31 : 
                d,m,y = parts_int[0], parts_int[1], parts_int[2]
            else: 
                 d,m,y = parts_int[0], parts_int[1], parts_int[2]

            if y < 100: 
                 y += 2000 if y < 50 else 1900 
            return date(y, m, d)
        except (ValueError, IndexError):
            pass
    return None

def calculate_age(birth_date: date) -> int:
    today = date.today()
    age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
    return age

def get_name_from_fio(fio: str | None) -> str:
    if not fio:
        return "кандидат" 
    parts = fio.split()
    if len(parts) > 1: 
        return parts[1] 
    elif len(parts) == 1 and parts[0]: 
        return parts[0]
    return "кандидат"


async def generate_gemini_response(
    user_id: int,
    current_stage_id_for_prompt: str,
    current_task_instruction_template: str, 
    actual_bot_name_for_gemini: str,
    user_message_text_for_history: str | None = None
) -> str:
    if not gemini_model:
        logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Модель Gemini не инициализирована. Не могу сгенерировать ответ для пользователя {user_id}.")
        return "Извините, в данный момент я не могу обработать ваш запрос. Пожалуйста, попробуйте связаться позже."

    state = get_user_state(user_id)
    if user_message_text_for_history: 
        add_to_chat_history(user_id, "user", user_message_text_for_history)
        state = get_user_state(user_id) 

    anketa_answers = state.get("anketa_answers", {})
    
    format_kwargs = {
        "bot_name": actual_bot_name_for_gemini,
        "company_name": COMPANY_NAME,
        "company_city": COMPANY_CITY,
        "current_stage_id": current_stage_id_for_prompt,
        "candidate_fio_full": anketa_answers.get("fio", "кандидат"),
        "candidate_name_short_form": get_name_from_fio(anketa_answers.get("fio")),
        "candidate_salary_expectation": anketa_answers.get("motivation_salary_expectations", "не указаны"),
        "candidate_self_employment_response_placeholder": anketa_answers.get("self_employment_preference", "ответ не получен")
    }

    final_task_instruction = current_task_instruction_template.format(**format_kwargs)
    format_kwargs["current_task_instruction"] = final_task_instruction 

    system_prompt_text = IMPROVED_SYSTEM_PROMPT_TEMPLATE.format(**format_kwargs)
    
    contents_for_gemini_api = [{"role": "user", "parts": [{"text": system_prompt_text}]}]
    
    chat_history_for_api = state.get("chat_history", [])
    if chat_history_for_api:
        last_added_role = "user" 
        for history_entry in chat_history_for_api:
            if history_entry["role"] == last_added_role and history_entry["role"] == "model": 
                continue
            if history_entry["role"] == "user" and last_added_role == "user" and len(contents_for_gemini_api) > 1 : 
                if contents_for_gemini_api[-1]["parts"] and history_entry["parts"]:
                     contents_for_gemini_api[-1]["parts"][0]["text"] += "\n" + history_entry["parts"][0]["text"]
                continue
            contents_for_gemini_api.append(history_entry)
            last_added_role = history_entry["role"]
    
    if user_message_text_for_history and (not chat_history_for_api or contents_for_gemini_api[-1]["role"] == "model"):
         if contents_for_gemini_api[-1]["role"] == "model":
            contents_for_gemini_api.append({"role": "user", "parts": [{"text": user_message_text_for_history}]})

    logger.debug(f"Агент '{TELEGRAM_SESSION_NAME}': Запрос Gemini для {user_id}. Этап: {current_stage_id_for_prompt}. Сообщений в `contents`: {len(contents_for_gemini_api)}. Последнее сообщение пользователя: '{user_message_text_for_history if user_message_text_for_history else 'Нет (начало диалога)'}'")

    safety_settings_config = {
        HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_NONE,
        HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_NONE,
        HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_NONE,
        HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
    }

    try:
        gemini_api_response = await gemini_model.generate_content_async(
            contents=contents_for_gemini_api,
            generation_config=genai.types.GenerationConfig(temperature=0.75, top_p=0.95, top_k=40),
            safety_settings=safety_settings_config
        )
        bot_response_text = ""
        if gemini_api_response.candidates and gemini_api_response.candidates[0].content.parts:
            bot_response_text = "".join(part.text for part in gemini_api_response.candidates[0].content.parts)
        
        if not bot_response_text:
            block_reason_msg = "Причина неизвестна"
            if gemini_api_response.prompt_feedback and gemini_api_response.prompt_feedback.block_reason:
                block_reason_msg = gemini_api_response.prompt_feedback.block_reason.name
            logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Gemini вернул пустой ответ для {user_id}. Причина: {block_reason_msg}. Содержимое запроса (первые 500 символов системного промпта): {system_prompt_text[:500]}")
            if gemini_api_response.prompt_feedback and gemini_api_response.prompt_feedback.block_reason:
                return "К сожалению, я не могу обработать ваш последний запрос. Давайте попробуем другую формулировку?"
            return "Простите, не совсем поняла вас. Можете повторить?"
            
        add_to_chat_history(user_id, "model", bot_response_text) # Добавляем ответ модели в историю
        return bot_response_text.strip()
    except Exception as e_gemini_call:
        logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка Gemini API для {user_id}: {type(e_gemini_call).__name__} - {e_gemini_call}", exc_info=True)
        return f"Ой, кажется, у меня небольшие технические неполадки. Попробуйте написать чуть позже, пожалуйста. ({actual_bot_name_for_gemini} 😊)"


async def handle_user_message(user_id: int, message_text: str, actual_bot_name: str) -> str:
    state = get_user_state(user_id)
    
    # Проверка на завершенный диалог из-за мата в самом начале
    if state.get("dialogue_terminated_profanity"):
        logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Диалог с пользователем {user_id} ранее был завершен из-за ненормативной лексики. Игнорирование сообщения: '{message_text[:50]}...'")
        # Не добавляем сообщение пользователя в историю, так как мы его игнорируем
        return "" # Возвращаем пустую строку, чтобы не было ответа

    current_stage_id = state.get("current_stage_id", SCENARIO["initial_stage_id"])
    anketa_answers = state.get("anketa_answers", {})

    # Сохраняем сообщение пользователя в историю до обработки мата, 
    # чтобы оно было в контексте, если это первый мат.
    # Если это второй мат, сообщение все равно будет в истории, но ответа не последует.
    # Однако, если мы хотим полностью игнорировать, то и в историю не добавляем.
    # Давайте примем решение НЕ ДОБАВЛЯТЬ матерное сообщение в историю, если оно приводит к блокировке.
    
    user_message_to_log_and_history = message_text # Для передачи в generate_gemini_response

    if message_text and contains_profanity(message_text):
        strikes = increment_profanity_strike(user_id)
        if strikes == 1:
            bot_response = "Пожалуйста, давайте придерживаться делового стиля общения. При повторном использовании ненормативной лексики я буду вынуждена прекратить диалог."
            # Не добавляем само матерное сообщение пользователя в историю для Gemini
            # но добавляем ответ бота
            add_to_chat_history(user_id, "model", bot_response) 
            return bot_response
        else: # strikes >= 2
            bot_response = "К сожалению, из-за нарушения правил общения я вынуждена прекратить наш диалог. Всего доброго."
            state["dialogue_terminated_profanity"] = True 
            save_user_state(user_id, state) 
            # Добавляем последнее сообщение бота в историю, но не матерное сообщение пользователя
            add_to_chat_history(user_id, "model", bot_response)
            logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Диалог с пользователем {user_id} завершен из-за повторного использования ненормативной лексики.")
            return bot_response # Отправляем это последнее сообщение и всё
    
    # Если мата не было, или это был первый случай (и мы уже вернули предупреждение), продолжаем обычную логику
    
    if current_stage_id not in SCENARIO["stages"]:
        logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Неизвестный этап {current_stage_id} для {user_id}. Сброс на начальный.")
        current_stage_id = SCENARIO["initial_stage_id"]
        state["current_stage_id"] = current_stage_id
        save_user_state(user_id, state) # Сохраняем сброшенное состояние

    current_stage_data = SCENARIO["stages"][current_stage_id]
    gemini_instruction_template_for_stage = current_stage_data["instruction_for_gemini"]
    next_stage_to_set = current_stage_data.get("next_stage_default")
    anketa_key_to_save = current_stage_data.get("anketa_key_to_save")

    user_input_for_anketa = message_text.strip() if message_text else ""
    
    # Логика обработки ответа пользователя для анкеты
    if current_stage_id == "INIT_GREETING" and not anketa_answers.get("fio") and user_input_for_anketa:
        positive_responses = ["хорошо", "да", "давайте", "ок", "согласен", "согласна", "готов", "готова"]
        # Проверяем, является ли ответ коротким согласием, а не ФИО
        is_positive_short_response = any(pr in user_input_for_anketa.lower().split() for pr in positive_responses) and len(user_input_for_anketa.split()) <= 2

        if is_positive_short_response:
            # Это согласие, не ФИО. Gemini должен задать вопрос про ФИО снова.
            anketa_key_to_save = None # Не сохраняем этот ответ как ФИО
            next_stage_to_set = current_stage_id # Остаемся на том же этапе
        elif anketa_key_to_save == "fio": # Убедимся, что это вопрос про ФИО
             update_anketa_answer(user_id, anketa_key_to_save, user_input_for_anketa)
             anketa_answers[anketa_key_to_save] = user_input_for_anketa # Обновляем локальную копию для текущей обработки

    elif anketa_key_to_save and user_input_for_anketa: # Для всех остальных этапов с сохранением
        update_anketa_answer(user_id, anketa_key_to_save, user_input_for_anketa)
        anketa_answers[anketa_key_to_save] = user_input_for_anketa # Обновляем локальную копию

        # Специальная логика после получения даты рождения (DOB)
        if anketa_key_to_save == "dob":
            dob_date = parse_dob(user_input_for_anketa)
            if dob_date:
                age = calculate_age(dob_date)
                update_anketa_answer(user_id, "calculated_age", str(age)) 
                logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Пользователь {user_id} указал ДР {dob_date}, возраст: {age}")
                if age < 18:
                    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Пользователь {user_id} младше 18 лет ({age}). Переход на этап AGE_REJECT.")
                    current_stage_id = SCENARIO["age_rejection_stage_id"]
                    # gemini_instruction_template_for_stage будет обновлена ниже
                    next_stage_to_set = None # Это терминальный этап для AGE_REJECT
            else: # Если дата не распознана
                logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Не удалось распознать дату рождения: '{user_input_for_anketa}' от пользователя {user_id}.")
                # Остаемся на этапе ASK_DOB, Gemini должен переспросить
                next_stage_to_set = current_stage_id 
    
    # Если мы перешли на AGE_REJECT из-за возраста, нужно обновить current_stage_data и инструкцию
    if current_stage_id == SCENARIO["age_rejection_stage_id"]:
        current_stage_data = SCENARIO["stages"][current_stage_id]
        gemini_instruction_template_for_stage = current_stage_data["instruction_for_gemini"]
        # next_stage_to_set уже None или должен быть None

    # Если кандидат пишет после завершения анкеты
    if current_stage_id == SCENARIO["anketa_completed_stage_id"] and state.get("chat_history") and message_text:
        # Проверяем, что это не первое сообщение в этом состоянии (chat_history уже есть)
        # и что пользователь действительно что-то написал (message_text не пустой)
        logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Пользователь {user_id} (анкета завершена) пишет снова. Переход в WARM_UP.")
        current_stage_id = "WARM_UP_CANDIDATE"
        current_stage_data = SCENARIO["stages"][current_stage_id]
        gemini_instruction_template_for_stage = current_stage_data["instruction_for_gemini"]
        next_stage_to_set = "WARM_UP_CANDIDATE" # Остаемся в этом состоянии
    
    # Генерируем ответ бота
    # user_message_to_log_and_history (оригинальное сообщение пользователя) передается для добавления в историю внутри generate_gemini_response
    bot_response = await generate_gemini_response(
        user_id,
        current_stage_id_for_prompt=current_stage_id,
        current_task_instruction_template=gemini_instruction_template_for_stage, 
        actual_bot_name_for_gemini=actual_bot_name,
        user_message_text_for_history=user_message_to_log_and_history 
    )

    # Логика перехода на следующий этап
    if next_stage_to_set and next_stage_to_set != current_stage_id: 
        advance_user_stage(user_id, next_stage_to_set)
    elif not next_stage_to_set and current_stage_id == SCENARIO["age_rejection_stage_id"]: 
        advance_user_stage(user_id, current_stage_id) # Сохраняем состояние с текущим (терминальным) этапом
    elif not next_stage_to_set : # Для других этапов без next_stage_default (например, AWAITING_DECISION_AFTER_ANKETA)
        advance_user_stage(user_id, current_stage_id) # Обновляем TTL и last_activity
        
    return bot_response