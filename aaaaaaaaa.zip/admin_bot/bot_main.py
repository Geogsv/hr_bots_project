# admin_bot/bot_main.py
from telegram.ext import (
    Application, CommandHandler, MessageHandler, filters,
    ConversationHandler, CallbackQueryHandler
)
from telegram import Update
from config import (
    ADMIN_BOT_TOKEN, logger, admin_redis_client, DOCKER_CLIENT, DOCKER_AGENT_IMAGE_NAME
)
from handlers.commands import start_panel_command, list_agents_command_handler
from handlers.callbacks import button_callback_handler
from handlers.conversation_add_agent import (
    add_agent_command_entry,
    received_session_name, received_api_id, received_api_hash,
    received_session_string, received_bot_name, received_use_proxy,
    received_proxy_type, received_proxy_host, received_proxy_port,
    received_proxy_username, received_proxy_password,
    cancel_add_agent
)
from constants import (
    ASK_SESSION_NAME, ASK_API_ID, ASK_API_HASH, ASK_SESSION_STRING, ASK_BOT_NAME,
    ASK_USE_PROXY, ASK_PROXY_TYPE, ASK_PROXY_HOST, ASK_PROXY_PORT, ASK_PROXY_USERNAME,
    ASK_PROXY_PASSWORD
)

def run_admin_bot() -> None:
    if not admin_redis_client:
        logger.critical("КРИТИКА (bot_main): AdminBot не может запуститься без Redis. Проверьте config.py и подключение.")
        return
    if not DOCKER_CLIENT: # Теперь это предупреждение, т.к. config.py не падает если Docker нет
        logger.warning("ПРЕДУПРЕЖДЕНИЕ (bot_main): Docker клиент не инициализирован. Функционал управления агентами будет недоступен.")
    if not ADMIN_BOT_TOKEN:
        logger.critical("КРИТИКА (bot_main): ADMIN_BOT_TOKEN не установлен. Бот не может запуститься.")
        return
    application = Application.builder().token(ADMIN_BOT_TOKEN).build()
    add_agent_conv_handler = ConversationHandler(
        entry_points=[CommandHandler('add_agent', add_agent_command_entry)],
        states={
            ASK_SESSION_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_session_name)],
            ASK_API_ID: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_api_id)],
            ASK_API_HASH: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_api_hash)],
            ASK_SESSION_STRING: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_session_string)],
            ASK_BOT_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_bot_name)],
            ASK_USE_PROXY: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_use_proxy)],
            ASK_PROXY_TYPE: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_proxy_type)],
            ASK_PROXY_HOST: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_proxy_host)],
            ASK_PROXY_PORT: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_proxy_port)],
            ASK_PROXY_USERNAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_proxy_username)],
            ASK_PROXY_PASSWORD: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_proxy_password)],
        },
        fallbacks=[CommandHandler('cancel', cancel_add_agent)],
        conversation_timeout=20 * 60
    )
    application.add_handler(CommandHandler(["start", "panel"], start_panel_command))
    application.add_handler(CommandHandler("list_agents", list_agents_command_handler))
    application.add_handler(add_agent_conv_handler)
    application.add_handler(CallbackQueryHandler(button_callback_handler))
    logger.info(f"Управляющий бот запущен. Образ для запускаемых агентов: {DOCKER_AGENT_IMAGE_NAME}")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    run_admin_bot()