# admin_bot/redis_utils.py
import json
from typing import Dict, Any
import redis
from config import admin_redis_client, REDIS_AGENTS_CONFIG_KEY, logger

def save_agents_config(config: Dict[str, Dict[str, Any]]):
    if not admin_redis_client:
        logger.error("Ошибка сохранения конфигурации агентов: Redis клиент не инициализирован.")
        return
    try:
        admin_redis_client.set(REDIS_AGENTS_CONFIG_KEY, json.dumps(config))
        logger.debug(f"Конфигурация агентов успешно сохранена в Redis по ключу: '{REDIS_AGENTS_CONFIG_KEY}'.")
    except (redis.exceptions.RedisError, TypeError) as e:
        logger.error(f"Ошибка при сохранении конфигурации агентов в Redis или при сериализации в JSON: {e}. Конфиг: {config}")

def load_agents_config() -> Dict[str, Dict[str, Any]]:
    if not admin_redis_client:
        logger.error("Ошибка загрузки конфигурации агентов: Redis клиент не инициализирован.")
        return {}
    try:
        config_json = admin_redis_client.get(REDIS_AGENTS_CONFIG_KEY)
        if config_json is None:
            logger.info(f"Конфигурация агентов не найдена в Redis по ключу ('{REDIS_AGENTS_CONFIG_KEY}'). Создаю пустую конфигурацию.")
            save_agents_config({})
            return {}
        config = json.loads(config_json) 
        return config if isinstance(config, dict) else {}
    except (redis.exceptions.RedisError, json.JSONDecodeError) as e:
        logger.error(f"Ошибка при загрузке или декодировании конфигурации агентов из Redis: {e}.")
        return {}

def update_agent_status_in_config_file(session_name: str, status_message: str, is_active: bool | None = None):
    agents = load_agents_config()
    if session_name in agents:
        agents[session_name]["status_message"] = status_message
        if is_active is not None:
            agents[session_name]["is_active"] = is_active
        save_agents_config(agents)
        logger.debug(f"Статус агента {session_name} обновлен: '{status_message}', active: {is_active if is_active is not None else 'не изменен'}.")
    else:
        logger.warning(f"Попытка обновить статус для несуществующего в конфигурации агента: {session_name}")