# agent_bot/agent_main.py
import asyncio
import random
import python_socks # type: ignore
from telethon import TelegramClient, events # type: ignore
from telethon.sessions import StringSession # type: ignore
from telethon.errors import ( # type: ignore
    UserNotParticipantError, ChannelPrivateError, ChatWriteForbiddenError,
    UserIsBlockedError, FloodWaitError, AuthKeyError, UnauthorizedError, UserDeactivatedError, SessionExpiredError,
    RPCError
)
import redis # Для redis.exceptions
from datetime import datetime, time, timedelta, timezone

from config import (
    logger, TELEGRAM_API_ID, TELEGRAM_API_HASH, TELEGRAM_SESSION_STRING,
    TELEGRAM_SESSION_NAME, REDIS_HOST, REDIS_PORT, redis_client,
    TELETHON_PROXY_SETTINGS, CURRENT_BOT_NAME, gemini_model, BOT_NAME_FROM_ENV,
    DAILY_REMINDER_ENABLED, COMPANY_NAME
)
from message_handler import handle_user_message
from state_manager import get_user_state, save_user_state, update_last_warmup_sent_time, get_redis_key_for_user_state
from constants import SCENARIO

client: TelegramClient | None = None
bot_dynamic_name: str | None = CURRENT_BOT_NAME # Инициализируется из config


# --- Параметры для имитации времени печати ---
AVERAGE_WPM = 35  # Средняя скорость печати слов в минуту (немного медленнее)
MIN_DELAY_S = 1.2   # Минимальная задержка перед отправкой (в секундах)
MAX_DELAY_S = 6.0   # Максимальная задержка (в секундах)
RANDOM_FACTOR_TYPING = 0.4 # Добавляет случайности к задержке печати (40%)
MIN_THINKING_DELAY_S = 0.5 # Минимальная задержка "обдумывания"
MAX_THINKING_DELAY_S = 1.8 # Максимальная задержка "обдумывания"

def calculate_typing_delay(text: str) -> float:
    if not text:
        return MIN_DELAY_S
    words = len(text.split())
    if AVERAGE_WPM <= 0: return MIN_DELAY_S
    words_per_second = AVERAGE_WPM / 60.0
    if words_per_second <= 0: return MIN_DELAY_S
    delay_based_on_words = words / words_per_second
    random_offset = delay_based_on_words * RANDOM_FACTOR_TYPING
    delay = delay_based_on_words + random.uniform(-random_offset, random_offset)
    return max(MIN_DELAY_S, min(delay, MAX_DELAY_S))

# --- Ежедневные напоминания ---
async def daily_candidate_warmup_task():
    if not DAILY_REMINDER_ENABLED:
        logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Ежедневные напоминания отключены.")
        return

    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Задача ежедневных напоминаний запущена (целевое время 14:00 МСК).")
    moscow_tz = timezone(timedelta(hours=3))
    target_reminder_hour_moscow = 14 # Целевой час для напоминаний (14:00 МСК)

    while client and client.is_connected():
        try:
            now_utc = datetime.now(timezone.utc)
            now_moscow = now_utc.astimezone(moscow_tz)

            if now_moscow.hour == target_reminder_hour_moscow:
                logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Наступило время для отправки ежедневных напоминаний ({now_moscow.strftime('%H:%M')} МСК).")
                if not redis_client:
                    logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}' (WarmupTask): Redis недоступен, пропускаю итерацию.")
                    await asyncio.sleep(60 * 30) 
                    continue

                user_state_keys = []
                try:
                    cursor = '0'
                    while True:
                        cursor, keys = await asyncio.to_thread(
                            redis_client.scan, 
                            cursor, 
                            match=f"agent:{TELEGRAM_SESSION_NAME}:user_state:*",
                            count=100
                        )
                        user_state_keys.extend(keys)
                        if cursor == b'0' or cursor == 0 :
                            break
                except Exception as e_scan:
                    logger.error(f"Агент '{TELEGRAM_SESSION_NAME}' (WarmupTask): Ошибка при сканировании ключей Redis: {e_scan}")
                    await asyncio.sleep(60 * 60) 
                    continue
                
                logger.info(f"Агент '{TELEGRAM_SESSION_NAME}' (WarmupTask): Найдено {len(user_state_keys)} ключей состояния для проверки.")

                processed_today_count = 0
                for key_bytes in user_state_keys:
                    key = key_bytes.decode('utf-8')
                    user_id_str = key.split(':')[-1]
                    if not user_id_str.isdigit():
                        continue
                    user_id = int(user_id_str)

                    user_state = get_user_state(user_id)
                    
                    if user_state.get("current_stage_id") == SCENARIO["anketa_completed_stage_id"]:
                        last_warmup_iso = user_state.get("last_warmup_message_sent_at_iso")
                        should_send = True
                        if last_warmup_iso:
                            last_warmup_dt_utc = datetime.fromisoformat(last_warmup_iso)
                            last_warmup_dt_moscow = last_warmup_dt_utc.astimezone(moscow_tz)
                            if (now_utc - last_warmup_dt_utc).total_seconds() < 23 * 60 * 60 and \
                               last_warmup_dt_moscow.date() == now_moscow.date():
                                should_send = False
                        
                        if should_send:
                            processed_today_count +=1
                            candidate_fio = user_state.get("anketa_answers", {}).get("fio")
                            candidate_name_display = "Уважаемый кандидат"
                            if candidate_fio: # Убедимся, что fio не None и не пустое
                                name_parts = candidate_fio.split(" ")
                                if len(name_parts) > 1: # Если есть хотя бы два слова (Имя Фамилия)
                                    candidate_name_display = name_parts[1] # Берем второе слово как имя
                                elif len(name_parts) == 1 and name_parts[0]: # Если только одно слово и оно не пустое
                                    candidate_name_display = name_parts[0] # Берем его
                            
                            warmup_message = (
                                f"Здравствуйте, {candidate_name_display}! Напоминаем, что ваша анкета для {COMPANY_NAME} находится на рассмотрении. "
                                f"Мы помним о вас и обязательно свяжемся, как только появятся новости. "
                                f"Благодарим за ваше терпение!"
                            )
                            try:
                                if client:
                                    await client.send_message(user_id, warmup_message)
                                    update_last_warmup_sent_time(user_id)
                                    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}' (WarmupTask): Отправлено напоминание пользователю {user_id}.")
                                    await asyncio.sleep(random.uniform(5, 15))
                            except (UserIsBlockedError, ChatWriteForbiddenError, UserDeactivatedError):
                                logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}' (WarmupTask): Не удалось отправить напоминание пользователю {user_id} (заблокирован/покинул и т.д.).")
                            except FloodWaitError as e_flood:
                                wait_time = e_flood.seconds + random.randint(5,10)
                                logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}' (WarmupTask): FloodWait при отправке напоминания. Ожидание {wait_time} сек.")
                                await asyncio.sleep(wait_time)
                            except Exception as e_send_warmup:
                                logger.error(f"Агент '{TELEGRAM_SESSION_NAME}' (WarmupTask): Ошибка при отправке напоминания пользователю {user_id}: {e_send_warmup}")
                
                logger.info(f"Агент '{TELEGRAM_SESSION_NAME}' (WarmupTask): Завершена обработка напоминаний за {now_moscow.date()}. Отправлено: {processed_today_count}.")
                next_run_time_moscow = datetime.combine(now_moscow.date() + timedelta(days=1), time(target_reminder_hour_moscow, 0), tzinfo=moscow_tz)
                time_to_sleep_seconds = (next_run_time_moscow - now_moscow).total_seconds()

                if time_to_sleep_seconds < 0 : time_to_sleep_seconds = 23*60*60 
                
                logger.info(f"Агент '{TELEGRAM_SESSION_NAME}' (WarmupTask): Следующая проверка для напоминаний примерно через {time_to_sleep_seconds / 3600:.1f} часов.")
                await asyncio.sleep(time_to_sleep_seconds)

            else: 
                target_dt_moscow_today = datetime.combine(now_moscow.date(), time(target_reminder_hour_moscow, 0), tzinfo=moscow_tz)
                
                if now_moscow >= target_dt_moscow_today: 
                    target_dt_moscow_next_day = datetime.combine(now_moscow.date() + timedelta(days=1), time(target_reminder_hour_moscow, 0), tzinfo=moscow_tz)
                    time_to_sleep_seconds = (target_dt_moscow_next_day - now_moscow).total_seconds()
                else: 
                    time_to_sleep_seconds = (target_dt_moscow_today - now_moscow).total_seconds()

                if time_to_sleep_seconds < 60 : time_to_sleep_seconds = 60 
                
                logger.debug(f"Агент '{TELEGRAM_SESSION_NAME}' (WarmupTask): Текущее время МСК {now_moscow.strftime('%H:%M')}, не целевой час для напоминаний. Ожидание {time_to_sleep_seconds / 60:.1f} минут.")
                await asyncio.sleep(time_to_sleep_seconds)

        except RPCError as e_rpc_warmup: 
            logger.error(f"Агент '{TELEGRAM_SESSION_NAME}' (WarmupTask): Ошибка RPC Telethon: {e_rpc_warmup}. Попытка продолжить через 5 минут.")
            await asyncio.sleep(5 * 60)
        except Exception as e_warmup_task:
            logger.error(f"Агент '{TELEGRAM_SESSION_NAME}' (WarmupTask): Непредвиденная ошибка в задаче напоминаний: {e_warmup_task}", exc_info=True)
            await asyncio.sleep(60 * 15)

async def run_agent():
    global client, bot_dynamic_name # bot_dynamic_name - глобальная переменная
    if not redis_client:
        logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}' не может запуститься без Redis. Проверьте конфигурацию Redis.")
        return
    if not gemini_model:
        logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}' не может запуститься без Gemini. Проверьте конфигурацию Gemini.")
        return
    if not TELEGRAM_SESSION_STRING:
        logger.critical(f"КРИТИКА: TELEGRAM_SESSION_STRING не предоставлена для агента '{TELEGRAM_SESSION_NAME}'. Агент не может запуститься.")
        return
    if not TELEGRAM_API_ID or not TELEGRAM_API_HASH or not TELEGRAM_SESSION_NAME:
        logger.critical(f"КРИТИКА: TELEGRAM_API_ID, HASH или SESSION_NAME не установлены для агента. Агент не может запуститься.")
        return
        
    logger.info(f"Запуск логики агента '{TELEGRAM_SESSION_NAME}'...")
    session_to_use = StringSession(TELEGRAM_SESSION_STRING)
    proxy_arg_for_telethon = None
    if TELETHON_PROXY_SETTINGS:
        proxy_arg_for_telethon = (
            TELETHON_PROXY_SETTINGS["proxy_type"], TELETHON_PROXY_SETTINGS["addr"],
            TELETHON_PROXY_SETTINGS["port"], TELETHON_PROXY_SETTINGS["rdns"],
            TELETHON_PROXY_SETTINGS["username"], TELETHON_PROXY_SETTINGS["password"]
        )
    client = TelegramClient(session_to_use, TELEGRAM_API_ID, TELEGRAM_API_HASH, proxy=proxy_arg_for_telethon)
    logger.info("Клиент Telethon инициализирован" + (" с прокси." if proxy_arg_for_telethon else "."))

    # Функция для получения/установки имени бота
    async def ensure_bot_name_is_set():
        global bot_dynamic_name # Указываем, что работаем с глобальной переменной
        if bot_dynamic_name: # Если имя уже установлено (из env или ранее)
            return

        if BOT_NAME_FROM_ENV: # Сначала проверяем env, если имя еще не было установлено
            bot_dynamic_name = BOT_NAME_FROM_ENV
            logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Имя бота установлено из переменной окружения: {bot_dynamic_name}")
            return

        if not client or not client.is_connected() or not await client.is_user_authorized():
            logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Невозможно получить имя бота из профиля - клиент не готов. Будет использовано временное имя.")
            # bot_dynamic_name останется None, current_effective_bot_name будет использовать fallback
            return

        try:
            me = await client.get_me()
            if me:
                bot_dynamic_name = me.first_name + (f" {me.last_name}" if me.last_name else "")
                logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Имя бота установлено из профиля Telegram: {bot_dynamic_name}")
            else:
                logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Не удалось получить 'me' из профиля. Используется временное имя.")
        except Exception as e_me:
            logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка при получении имени бота из профиля: {e_me}. Используется временное имя.", exc_info=True)


    @client.on(events.NewMessage(incoming=True, forwards=False))
    async def new_message_listener(event: events.NewMessage.Event):
        # global bot_dynamic_name # Уже объявлена на уровне модуля, здесь не нужна, если не переприсваиваем сам bot_dynamic_name
        # Мы вызываем ensure_bot_name_is_set, которая работает с глобальной переменной
        
        if not client or not client.is_connected():
            logger.warning(f"Получено сообщение для агента '{TELEGRAM_SESSION_NAME}', но клиент Telethon не активен/не подключен.")
            return
        if event.is_private and not event.message.out:
            user_id = event.sender_id
            message_text = event.text.strip() if event.text else ""
            logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Получено сообщение от пользователя {user_id}: '{message_text[:50]}...'")
            
            await ensure_bot_name_is_set() # Убеждаемся, что имя бота установлено
            
            # Используем bot_dynamic_name (глобальную) или fallback, если она все еще None
            current_effective_bot_name = bot_dynamic_name or f"Оператор {COMPANY_NAME}" 
            
            thinking_delay = random.uniform(MIN_THINKING_DELAY_S, MAX_THINKING_DELAY_S)
            logger.debug(f"Агент '{TELEGRAM_SESSION_NAME}': Имитация 'обдумывания'. Задержка: {thinking_delay:.2f} сек.")
            await asyncio.sleep(thinking_delay)
            
            async with client.action(event.chat_id, 'typing'):
                bot_reply_text = await handle_user_message(user_id, message_text, current_effective_bot_name)

                if bot_reply_text:
                    typing_simulation_delay = calculate_typing_delay(bot_reply_text)
                    logger.debug(f"Агент '{TELEGRAM_SESSION_NAME}': Имитация печати. Задержка: {typing_simulation_delay:.2f} сек. для сообщения: '{bot_reply_text[:30]}...'")
                    
                    time_slept = 0
                    action_refresh_interval = 4.0 
                    while time_slept < typing_simulation_delay:
                        sleep_chunk = min(action_refresh_interval, typing_simulation_delay - time_slept)
                        await asyncio.sleep(sleep_chunk)
                        time_slept += sleep_chunk
                        if time_slept < typing_simulation_delay and client and client.is_connected(): 
                            try:
                                await client.send_read_acknowledge(event.chat_id, event.message, action='typing')
                            except Exception as e_typing_refresh:
                                logger.debug(f"Агент '{TELEGRAM_SESSION_NAME}': Незначительная ошибка при обновлении статуса 'typing': {e_typing_refresh}")


                    try:
                        await event.respond(bot_reply_text)
                        logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Ответ для пользователя {user_id} отправлен: '{bot_reply_text[:50]}...'")
                    except (ChatWriteForbiddenError, UserIsBlockedError, UserDeactivatedError) as e_perm:
                        logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Не удалось отправить сообщение пользователю {user_id} (блок/запрет/деактивирован): {e_perm}")
                    except FloodWaitError as e_flood:
                        wait_time = e_flood.seconds + random.randint(1,5) 
                        logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': FloodWait при отправке пользователю {user_id}. Ожидание {wait_time} сек.")
                        await asyncio.sleep(wait_time)
                        try:
                            await event.respond(bot_reply_text)
                            logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Сообщение пользователю {user_id} успешно отправлено после FloodWait.")
                        except Exception as e_retry:
                            logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка повторной отправки сообщения пользователю {user_id} после FloodWait: {e_retry}", exc_info=True)
                    except Exception as e_send:
                        logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Общая ошибка при отправке сообщения пользователю {user_id}: {e_send}", exc_info=True)
                else:
                    logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Сгенерирован пустой ответ для пользователя {user_id} (возможно, диалог завершен из-за мата или другой причины), отправка не будет произведена.")
    
    warmup_task_handle = None
    try:
        logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Попытка подключения к Telegram (используется строка сессии)...")
        if not client:
             logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': Клиент Telethon не был инициализирован перед connect().")
             return
        await client.connect()
        if not client.is_connected():
            logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': Не удалось подключиться к Telegram после client.connect(). Остановка.")
            if client:
                try: await client.disconnect()
                except Exception as e_disc: logger.error(f"Ошибка при отключении клиента (после неудачного connect): {e_disc}")
            return
        if not await client.is_user_authorized(): 
            logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': АВТОРИЗАЦИЯ НЕ УДАЛАСЬ. Строка сессии недействительна или отозвана. Остановка агента.")
            if client and client.is_connected():
                try: await client.disconnect()
                except Exception as e_disc: logger.error(f"Ошибка при отключении клиента (после неудачной авторизации): {e_disc}")
            return

        await ensure_bot_name_is_set() # Устанавливаем имя бота после успешной авторизации
        final_bot_name_to_log = bot_dynamic_name or f"Оператор ({COMPANY_NAME})" # Используем глобальную переменную
        
        logger.info(f"Агент '{final_bot_name_to_log}' (сессия: {TELEGRAM_SESSION_NAME}) успешно авторизован и запущен. Redis: {REDIS_HOST}:{REDIS_PORT}. Ожидание сообщений...")
        
        if DAILY_REMINDER_ENABLED:
            warmup_task_handle = asyncio.create_task(daily_candidate_warmup_task())
            logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Фоновая задача для напоминаний создана.")
        
        await client.run_until_disconnected()

    except (AuthKeyError, SessionExpiredError, UserDeactivatedError, UnauthorizedError) as e_auth_critical:
        logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': КРИТИЧЕСКАЯ ОШИБКА АВТОРИЗАЦИИ/СЕССИИ: {type(e_auth_critical).__name__} - {e_auth_critical}. Обновите строку сессии. Агент будет остановлен.", exc_info=True)
    except (ConnectionRefusedError, OSError, python_socks.ProxyConnectionError, python_socks.ProxyError) as e_conn_critical: # type: ignore
        logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': КРИТИЧЕСКАЯ ОШИБКА СЕТИ/ПРОКСИ: {type(e_conn_critical).__name__} - {e_conn_critical}. Проверьте сетевое подключение, настройки прокси и DNS. Агент будет остановлен.", exc_info=True)
    except redis.exceptions.ConnectionError as e_redis_main:
        logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': КРИТИЧЕСКАЯ ОШИБКА Redis в основном потоке: {e_redis_main}. Агент будет остановлен.", exc_info=True)
    except Exception as e_global:
        logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}': Непредвиденная КРИТИЧЕСКАЯ ошибка в основном цикле `run_agent`: {type(e_global).__name__} - {e_global}. Агент будет остановлен.", exc_info=True)
    finally:
        if warmup_task_handle and not warmup_task_handle.done():
            warmup_task_handle.cancel()
            logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Попытка отмены задачи напоминаний.")
            try:
                await warmup_task_handle
            except asyncio.CancelledError:
                logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Задача напоминаний успешно отменена.")
            except Exception as e_cancel:
                logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка при ожидании отмены задачи напоминаний: {e_cancel}")


        if client and client.is_connected():
            logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Отключение от Telegram...")
            try:
                await client.disconnect()
            except Exception as e_disc_final:
                 logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка при финальном отключении клиента: {e_disc_final}")
        logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Процесс Telethon остановлен.")

if __name__ == '__main__':
    initial_display_name = BOT_NAME_FROM_ENV or f"Ассистент ({TELEGRAM_SESSION_NAME or 'Unknown'})"
    logger.info(f"Запуск экземпляра агента '{TELEGRAM_SESSION_NAME or 'Unknown'}' с начальным отображаемым именем '{initial_display_name}' через __main__...")
    try:
        asyncio.run(run_agent())
    except KeyboardInterrupt:
        logger.info(f"Агент '{TELEGRAM_SESSION_NAME or 'Unknown'}': Получен сигнал KeyboardInterrupt (Ctrl+C). Завершение работы...")
    except Exception as e_async_run:
        logger.critical(f"Агент '{TELEGRAM_SESSION_NAME or 'Unknown'}': Неперехваченная ошибка на уровне asyncio.run: {e_async_run}", exc_info=True)
    finally:
        logger.info(f"Агент '{TELEGRAM_SESSION_NAME or 'Unknown'}': Процесс завершен.")