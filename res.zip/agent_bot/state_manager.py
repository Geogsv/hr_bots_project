import json
from datetime import datetime, timezone
import redis
from config import (
    logger, redis_client, TELEGRAM_SESSION_NAME, USER_STATE_TTL_SECONDS
)
from constants import SCENARIO 

def get_redis_key_for_user_state(user_id: int) -> str:
    if not TELEGRAM_SESSION_NAME:
        logger.error("Критическая ошибка: TELEGRAM_SESSION_NAME не был инициализирован при попытке сформировать ключ Redis.")
        raise ValueError("TELEGRAM_SESSION_NAME (имя сессии агента) не определено в конфигурации.")
    return f"agent:{TELEGRAM_SESSION_NAME}:user_state:{user_id}"

def save_user_state(user_id: int, state: dict):
    if not redis_client:
        logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Redis клиент не инициализирован. Не могу сохранить состояние для пользователя {user_id}.")
        return
    try:
        key = get_redis_key_for_user_state(user_id)
        state["last_activity_iso"] = datetime.now(timezone.utc).isoformat()
        redis_client.setex(key, USER_STATE_TTL_SECONDS, json.dumps(state))
        logger.debug(f"Агент '{TELEGRAM_SESSION_NAME}': Состояние пользователя {user_id} сохранено. Этап: {state.get('current_stage_id')}. Ключевые ответы: {state.get('anketa_answers', {}).get('fio', 'N/A')}")
    except (redis.exceptions.RedisError, TypeError, json.JSONDecodeError) as e:
        logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка при сохранении состояния пользователя {user_id} в Redis: {e}", exc_info=True)

def get_user_state(user_id: int) -> dict:
    default_user_state = {
        "current_stage_id": SCENARIO["initial_stage_id"],
        "anketa_answers": {}, 
        "chat_history": [],
        "last_activity_iso": datetime.now(timezone.utc).isoformat(),
        "profanity_strikes": 0,
        "last_warmup_message_sent_at_iso": None # ISO timestamp
    }
    if not redis_client:
        logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Redis клиент не инициализирован. Возвращаю временное состояние по умолчанию для пользователя {user_id}.")
        return default_user_state.copy()
    
    key = get_redis_key_for_user_state(user_id)
    try:
        state_json_bytes = redis_client.get(key)
        if state_json_bytes:
            state_data = json.loads(state_json_bytes.decode('utf-8'))
            
            # Заполняем отсутствующие ключи значениями по умолчанию
            for k, v in default_user_state.items():
                if k not in state_data:
                    state_data[k] = v
            
            if "current_stage_id" not in state_data or state_data["current_stage_id"] not in SCENARIO["stages"]:
                logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': У пользователя {user_id} некорректный или отсутствующий этап '{state_data.get('current_stage_id')}'. Сброс на начальный.")
                state_data["current_stage_id"] = SCENARIO["initial_stage_id"]
            
            redis_client.expire(key, USER_STATE_TTL_SECONDS) # Продлеваем TTL
            logger.debug(f"Агент '{TELEGRAM_SESSION_NAME}': Состояние пользователя {user_id} загружено. Этап: {state_data.get('current_stage_id')}. TTL продлен.")
            # Не обновляем last_activity_iso здесь, это должно делаться при реальной активности
            return state_data
    except (redis.exceptions.RedisError, json.JSONDecodeError, TypeError) as e:
        logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка при загрузке состояния пользователя {user_id} из Redis: {e}", exc_info=True)
    
    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Для пользователя {user_id} не найдено состояние. Инициализация нового.")
    new_state = default_user_state.copy()
    # save_user_state(user_id, new_state) # Не сохраняем здесь, чтобы избежать двойного сохранения при первом get
    return new_state

def add_to_chat_history(user_id: int, role: str, text: str):
    state = get_user_state(user_id)
    if text and text.strip():
        state.setdefault("chat_history", []) 
        state["chat_history"].append({"role": role, "parts": [{"text": text.strip()}]})
        if len(state["chat_history"]) > 20: # Увеличим лимит истории
            state["chat_history"] = state["chat_history"][-20:]
        save_user_state(user_id, state)

def update_anketa_answer(user_id: int, answer_key: str, answer_value: str):
    state = get_user_state(user_id)
    state.setdefault("anketa_answers", {}) 
    # Очищаем значение перед сохранением, чтобы избежать слишком длинных строк, если Gemini что-то добавит
    clean_value = str(answer_value).strip() if answer_value is not None else ""

    state["anketa_answers"][answer_key] = clean_value
    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Пользователь {user_id} - анкета обновлена: {answer_key} = '{clean_value[:50]}...'")
    save_user_state(user_id, state)

def advance_user_stage(user_id: int, next_stage_id: str | None):
    if next_stage_id is None:
        logger.debug(f"Агент '{TELEGRAM_SESSION_NAME}': Для пользователя {user_id} не указан следующий этап. Этап не изменен.")
        # Просто обновим last_activity_iso и TTL
        state = get_user_state(user_id)
        save_user_state(user_id, state)
        return

    state = get_user_state(user_id)
    current_stage_log = state.get('current_stage_id', 'N/A')
    
    if next_stage_id not in SCENARIO["stages"]:
        logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Попытка перейти на несуществующий этап '{next_stage_id}' для пользователя {user_id}. Текущий этап: {current_stage_log}. Этап не изменен.")
        save_user_state(user_id, state) # Обновить TTL и last_activity
        return

    if state.get("current_stage_id") == next_stage_id:
        logger.debug(f"Агент '{TELEGRAM_SESSION_NAME}': Пользователь {user_id} уже на этапе '{next_stage_id}'. Переход не требуется.")
        save_user_state(user_id, state)
        return

    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Пользователь {user_id} переходит с этапа '{current_stage_log}' на этап '{next_stage_id}'")
    state["current_stage_id"] = next_stage_id
    save_user_state(user_id, state)


def increment_profanity_strike(user_id: int) -> int:
    state = get_user_state(user_id)
    state["profanity_strikes"] = state.get("profanity_strikes", 0) + 1
    save_user_state(user_id, state)
    return state["profanity_strikes"]

def get_profanity_strikes(user_id: int) -> int:
    state = get_user_state(user_id)
    return state.get("profanity_strikes", 0)

def update_last_warmup_sent_time(user_id: int):
    state = get_user_state(user_id)
    state["last_warmup_message_sent_at_iso"] = datetime.now(timezone.utc).isoformat()
    save_user_state(user_id, state)