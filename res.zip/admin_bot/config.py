import logging
import os
import json
import docker # type: ignore
import re
import redis # type: ignore
from dotenv import load_dotenv
from typing import List

dotenv_path = os.path.join(os.path.dirname(__file__), '.env')

if os.path.exists(dotenv_path):
    load_dotenv(dotenv_path)
    print(f"Загружен .env файл для admin_bot: {dotenv_path}")
else:
    print(f"Файл {dotenv_path} не найден. Попытка загрузить .env из родительской директории /app (если есть).")
    dotenv_path_alt = os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env') 
    if os.path.exists(dotenv_path_alt):
        load_dotenv(dotenv_path_alt)
        print(f"Загружен .env файл для admin_bot из: {dotenv_path_alt}")
    else:
        print(f"Предупреждение: .env файл для admin_bot не найден ни по пути {dotenv_path}, ни по {dotenv_path_alt}.")

ADMIN_BOT_TOKEN = os.getenv('ADMIN_BOT_TOKEN')
ADMIN_USER_IDS_STR = os.getenv('ADMIN_USER_IDS')
LOG_LEVEL_STR = os.getenv('LOG_LEVEL', 'INFO').upper()
DOCKER_AGENT_IMAGE_NAME = os.getenv('DOCKER_AGENT_IMAGE_NAME', 'hr_agent_image:latest')
GEMINI_API_KEY_FOR_AGENTS = os.getenv('GEMINI_API_KEY_FOR_AGENTS')
GEMINI_MODEL_NAME_FOR_AGENTS = os.getenv('GEMINI_MODEL_NAME_FOR_AGENTS', 'gemini-1.5-flash-latest')
AGENT_LOG_LEVEL = os.getenv('AGENT_LOG_LEVEL', 'INFO')

REDIS_HOST = os.getenv('REDIS_HOST', 'redis')
_redis_port_str = os.getenv('REDIS_PORT', '6379')
REDIS_PORT = int(_redis_port_str) if _redis_port_str and _redis_port_str.isdigit() else 6379
REDIS_AGENTS_CONFIG_KEY = os.getenv('REDIS_AGENTS_CONFIG_KEY', 'hr_bots:agents_config')

DOCKER_AGENT_NETWORK_NAME = os.getenv('DOCKER_AGENT_NETWORK_NAME', 'hr_bots_project_hr_bots_internal_network')

# Новые переменные для передачи агентам
COMPANY_NAME_FOR_AGENTS = os.getenv('COMPANY_NAME_FOR_AGENTS', "ООО 'Перспектива Роста'")
COMPANY_CITY_FOR_AGENTS = os.getenv('COMPANY_CITY_FOR_AGENTS', "г. Москва")
DAILY_REMINDER_ENABLED_FOR_AGENTS_STR = os.getenv('DAILY_REMINDER_ENABLED_FOR_AGENTS', 'true') # 'true' или 'false'
DAILY_REMINDER_ENABLED_FOR_AGENTS = DAILY_REMINDER_ENABLED_FOR_AGENTS_STR.lower() == 'true'


numeric_log_level = getattr(logging, LOG_LEVEL_STR, logging.INFO)
logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s', level=numeric_log_level)
logger = logging.getLogger("AdminBot")

admin_redis_client: redis.StrictRedis | None = None
try:
    admin_redis_client = redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=0, decode_responses=True)
    admin_redis_client.ping()
    logger.info(f"AdminBot: Успешное подключение к Redis: {REDIS_HOST}:{REDIS_PORT}")
except redis.exceptions.ConnectionError as e:
    logger.critical(f"AdminBot: КРИТИКА - Redis недоступен ({REDIS_HOST}:{REDIS_PORT}): {e}.", exc_info=True)
    admin_redis_client = None

AGENT_DNS_SERVERS_FROM_ENV_STR = os.getenv('AGENT_DNS_SERVERS')
AGENT_DNS_LIST_GLOBAL: List[str] = []
if AGENT_DNS_SERVERS_FROM_ENV_STR:
    try:
        AGENT_DNS_LIST_GLOBAL = [
            s.strip() for s in AGENT_DNS_SERVERS_FROM_ENV_STR.split(',')
            if s.strip() and re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", s.strip())
        ]
        if AGENT_DNS_LIST_GLOBAL:
            logger.info(f"DNS-серверы для агентов (из .env): {AGENT_DNS_LIST_GLOBAL}")
        else:
            logger.info("AGENT_DNS_SERVERS в .env указаны, но не содержат валидных IP. Будет использован DNS Docker по умолчанию.")
    except Exception as e:
        logger.warning(f"Не удалось разобрать AGENT_DNS_SERVERS ('{AGENT_DNS_SERVERS_FROM_ENV_STR}'): {e}. Будет использован DNS Docker по умолчанию.")
        AGENT_DNS_LIST_GLOBAL = []
else:
    logger.info("AGENT_DNS_SERVERS не установлены в .env. Будет использован DNS Docker по умолчанию.")

if not ADMIN_USER_IDS_STR: logger.critical("КРИТИКА: ADMIN_USER_IDS не установлен."); exit(1)
if not DOCKER_AGENT_IMAGE_NAME: logger.critical("КРИТИКА: DOCKER_AGENT_IMAGE_NAME не установлен."); exit(1)
if not GEMINI_API_KEY_FOR_AGENTS: logger.critical("КРИТИКА: GEMINI_API_KEY_FOR_AGENTS не установлен."); exit(1)

ADMIN_USER_IDS: List[int] = []
if ADMIN_USER_IDS_STR:
    try:
        ADMIN_USER_IDS = [int(admin_id.strip()) for admin_id in ADMIN_USER_IDS_STR.split(',')]
    except ValueError:
        logger.critical(f"КРИТИКА: ADMIN_USER_IDS ({ADMIN_USER_IDS_STR}) содержит нечисловое значение."); exit(1)
else:
    logger.critical("КРИТИКА: ADMIN_USER_IDS пуст или не установлен."); exit(1)

DOCKER_CLIENT: docker.DockerClient | None = None
try:
    DOCKER_CLIENT = docker.from_env()
    DOCKER_CLIENT.ping()
    logger.info("Docker клиент успешно инициализирован.")
except docker.errors.DockerException as e:
    logger.error(f"ПРЕДУПРЕЖДЕНИЕ: Docker Engine недоступен: {e}") 
    DOCKER_CLIENT = None