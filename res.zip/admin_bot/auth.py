# admin_bot/auth.py
from telegram import Update
from telegram.ext import ContextTypes
from config import ADMIN_USER_IDS, logger, admin_redis_client, DOCKER_CLIENT

def restricted(func):
    async def wrapped(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        if not update or not update.effective_user:
            logger.warning(f"Вызов {func.__name__} без update или effective_user.")
            return
        user_id = update.effective_user.id
        if user_id not in ADMIN_USER_IDS:
            logger.warning(f"Неавторизованный доступ от пользователя {user_id} к функции {func.__name__}")
            reply_text = "У вас нет прав для выполнения этого действия."
            if update.callback_query:
                await update.callback_query.answer(reply_text, show_alert=True)
            elif update.message:
                await update.message.reply_text(reply_text)
            return
        if not admin_redis_client:
            err_msg = "Действие невозможно: AdminBot не подключен к Redis."
            logger.error(err_msg + f" (при вызове {func.__name__} пользователем {user_id})")
            if update.callback_query: await update.callback_query.answer(err_msg, show_alert=True)
            elif update.message: await update.message.reply_text(err_msg)
            return
        if hasattr(func, '_requires_docker') and func._requires_docker and not DOCKER_CLIENT:
             err_msg = "Действие невозможно: Docker клиент недоступен."
             logger.error(err_msg + f" (при вызове {func.__name__} пользователем {user_id})")
             if update.callback_query: await update.callback_query.answer(err_msg, show_alert=True)
             elif update.message: await update.message.reply_text(err_msg)
             return
        return await func(update, context, *args, **kwargs)
    return wrapped

def requires_docker(func):
    func._requires_docker = True
    return func