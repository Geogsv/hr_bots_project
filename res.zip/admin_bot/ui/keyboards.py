# admin_bot/ui/keyboards.py
from telegram import InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes
from config import DOCKER_CLIENT, admin_redis_client
from constants import (
    ACTION_BACK_TO_LIST, ACTION_MAIN_MENU, ACTION_ADD_AGENT_CONV_START,
    ACTION_PREFIX_VIEW_AGENT, ACTION_PREFIX_TOGGLE_AGENT,
    ACTION_PREFIX_AGENT_LOGS, ACTION_PREFIX_CONFIRM_DELETE_AGENT,
    ACTION_PREFIX_DO_DELETE_AGENT
)
from typing import List, Dict, Any

async def get_main_menu_keyboard(context: ContextTypes.DEFAULT_TYPE) -> InlineKeyboardMarkup:
    keyboard_buttons = [
        [InlineKeyboardButton("📋 Список HR-Агентов", callback_data=ACTION_BACK_TO_LIST)],
    ]
    if DOCKER_CLIENT and admin_redis_client:
         keyboard_buttons.append(
             [InlineKeyboardButton("➕ Добавить нового HR-Агента", callback_data=ACTION_ADD_AGENT_CONV_START)]
         )
    return InlineKeyboardMarkup(keyboard_buttons)

def get_agents_list_layout(agents_data: Dict[str, Any], is_main_menu_context: bool) -> List[List[InlineKeyboardButton]]:
    layout_buttons: List[List[InlineKeyboardButton]] = []
    if agents_data:
        for session_name, agent_config in agents_data.items():
            is_active_status = agent_config.get("is_active", False)
            status_message_raw = agent_config.get("status_message", "N/A").replace("Docker: ", "")
            icon = "🟢" 
            if not is_active_status:
                if "не найден" in status_message_raw.lower(): icon = "⚪️" 
                elif "остановлен" in status_message_raw.lower() or "exited" in status_message_raw.lower(): icon = "⚫️" 
                else: icon = "🔴" 
            display_session_name = (session_name[:20] + '..') if len(session_name) > 22 else session_name
            layout_buttons.append([
                InlineKeyboardButton(
                    f"{icon} {display_session_name} ({status_message_raw})",
                    callback_data=f"{ACTION_PREFIX_VIEW_AGENT}{session_name}"
                )
            ])
    if DOCKER_CLIENT and admin_redis_client:
        layout_buttons.append(
            [InlineKeyboardButton("➕ Добавить нового HR-Агента", callback_data=ACTION_ADD_AGENT_CONV_START)]
        )
    if not is_main_menu_context:
         layout_buttons.append(
             [InlineKeyboardButton("🏠 В главное меню", callback_data=ACTION_MAIN_MENU)]
         )
    return layout_buttons

def get_agent_management_keyboard(session_name: str, is_agent_currently_active: bool) -> InlineKeyboardMarkup:
    toggle_button_text = "Стоп ⏹️ (Остановить агента)" if is_agent_currently_active else "Старт ▶️ (Запустить агента)"
    keyboard_layout = [
        [InlineKeyboardButton(toggle_button_text, callback_data=f"{ACTION_PREFIX_TOGGLE_AGENT}{session_name}")],
        [InlineKeyboardButton("📋 Показать логи (последние 20 строк)", callback_data=f"{ACTION_PREFIX_AGENT_LOGS}{session_name}")],
        [InlineKeyboardButton("🗑️ Удалить этого Агента", callback_data=f"{ACTION_PREFIX_CONFIRM_DELETE_AGENT}{session_name}")],
        [InlineKeyboardButton("⬅️ Назад к списку агентов", callback_data=ACTION_BACK_TO_LIST)]
    ]
    return InlineKeyboardMarkup(keyboard_layout)

def get_confirm_delete_keyboard(session_name: str) -> InlineKeyboardMarkup:
    display_name_on_button = (session_name[:15] + '..') if len(session_name) > 17 else session_name
    keyboard_layout = [
        [InlineKeyboardButton(
            f"✅ Да, удалить агента '{display_name_on_button}'", 
            callback_data=f"{ACTION_PREFIX_DO_DELETE_AGENT}{session_name}"
        )],
        [InlineKeyboardButton(
            "❌ Нет, отмена (вернуться к управлению)", 
            callback_data=f"{ACTION_PREFIX_VIEW_AGENT}{session_name}"
        )]
    ]
    return InlineKeyboardMarkup(keyboard_layout)